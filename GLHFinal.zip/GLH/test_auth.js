const axios = require('axios');

async function testLogin() {
  try {
    console.log('Testing login with existing producer...');
    
    // Test login with existing producer
    const response = await axios.post('http://localhost:5001/api/login', {
      email: 'john@thompsonfarm.local',
      password: 'password123'
    });
    
    console.log('Login response:', response.data);
    console.log('User data:', response.data.user);
    console.log('Producer ID:', response.data.user.producer_id);
    
  } catch (error) {
    console.error('Login error:', error.response?.data || error.message);
  }
}

testLogin();
