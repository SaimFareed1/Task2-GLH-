// Validation utility functions for GLH application

export const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password) => {
  // Password must be at least 8 characters, contain uppercase, lowercase, and number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
};

export const validateName = (name) => {
  // Name must be at least 2 characters and only contain letters, spaces, hyphens, and apostrophes
  const nameRegex = /^[a-zA-Z\s'-]{2,}$/;
  return nameRegex.test(name.trim());
};

export const validateAddress = (address) => {
  // Address must be at least 10 characters
  return address.trim().length >= 10;
};

export const validatePhone = (phone) => {
  // UK phone number validation
  const phoneRegex = /^(\+44|0)[1-9]\d{9,10}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
};

export const validateQuantity = (quantity, maxStock) => {
  const qty = parseInt(quantity);
  return !isNaN(qty) && qty > 0 && qty <= maxStock;
};

export const validatePrice = (price) => {
  const priceNum = parseFloat(price);
  return !isNaN(priceNum) && priceNum > 0 && priceNum <= 1000;
};

export const sanitizeInput = (input) => {
  // Basic input sanitization
  return input.trim().replace(/[<>]/g, '');
};

export const getValidationErrors = (formData, formType) => {
  const errors = {};

  switch (formType) {
    case 'register':
      if (!formData.full_name || !validateName(formData.full_name)) {
        errors.full_name = 'Please enter a valid name (at least 2 characters)';
      }
      if (!formData.email || !validateEmail(formData.email)) {
        errors.email = 'Please enter a valid email address';
      }
      if (!formData.password || !validatePassword(formData.password)) {
        errors.password = 'Password must be at least 8 characters with uppercase, lowercase, and number';
      }
      if (formData.password !== formData.confirmPassword) {
        errors.confirmPassword = 'Passwords do not match';
      }
      break;

    case 'login':
      if (!formData.email || !validateEmail(formData.email)) {
        errors.email = 'Please enter a valid email address';
      }
      if (!formData.password) {
        errors.password = 'Password is required';
      }
      break;

    case 'checkout':
      if (formData.orderType === 'delivery') {
        if (!formData.deliveryAddress || !validateAddress(formData.deliveryAddress)) {
          errors.deliveryAddress = 'Please enter a valid delivery address (at least 10 characters)';
        }
      }
      if (formData.orderType === 'collection') {
        if (!formData.collectionTime) {
          errors.collectionTime = 'Please select a collection time';
        }
      }
      if (formData.notes && formData.notes.length > 500) {
        errors.notes = 'Order notes must be less than 500 characters';
      }
      break;

    case 'product':
      if (!formData.name || formData.name.trim().length < 2) {
        errors.name = 'Product name must be at least 2 characters';
      }
      if (!formData.description || formData.description.trim().length < 10) {
        errors.description = 'Description must be at least 10 characters';
      }
      if (!formData.price || !validatePrice(formData.price)) {
        errors.price = 'Please enter a valid price (0.01 - 1000)';
      }
      if (!formData.stock || !validateQuantity(formData.stock, 10000)) {
        errors.stock = 'Please enter a valid stock quantity (1 - 10000)';
      }
      break;

    case 'producer':
      if (!formData.name || !validateName(formData.name)) {
        errors.name = 'Please enter a valid producer name';
      }
      if (!formData.location || formData.location.trim().length < 3) {
        errors.location = 'Please enter a valid location';
      }
      if (!formData.description || formData.description.trim().length < 20) {
        errors.description = 'Description must be at least 20 characters';
      }
      break;

    default:
      break;
  }

  return errors;
};

export const formatErrorMessage = (error) => {
  if (typeof error === 'string') return error;
  
  if (error.response) {
    // Server error
    if (error.response.data && error.response.data.message) {
      return error.response.data.message;
    }
    if (error.response.status === 400) return 'Invalid request data';
    if (error.response.status === 401) return 'Unauthorized - please login again';
    if (error.response.status === 403) return 'Access denied';
    if (error.response.status === 404) return 'Resource not found';
    if (error.response.status === 500) return 'Server error - please try again later';
  }
  
  if (error.request) {
    return 'Network error - please check your connection';
  }
  
  return 'An unexpected error occurred';
};

export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

export const throttle = (func, limit) => {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
};
