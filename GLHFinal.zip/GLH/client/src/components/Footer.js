import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { ThemeContext } from '../context/ThemeContext';

const Footer = () => {
  const { darkMode } = useContext(ThemeContext);

  const footerStyles = {
    footer: {
      backgroundColor: darkMode ? '#0d2818' : '#2d6a4f',
      color: '#f8f9fa',
      padding: '40px 20px 20px',
      borderTop: `1px solid ${darkMode ? '#1b4332' : '#40916c'}`,
      marginTop: 'auto'
    },
    container: {
      maxWidth: '1200px',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '40px',
      marginBottom: '30px'
    },
    column: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    },
    brandTitle: {
      fontSize: '20px',
      fontWeight: '700',
      marginBottom: '8px',
      color: '#ffffff'
    },
    tagline: {
      fontSize: '14px',
      lineHeight: '1.5',
      opacity: 0.9,
      maxWidth: '250px'
    },
    columnTitle: {
      fontSize: '16px',
      fontWeight: '600',
      marginBottom: '8px',
      color: '#ffffff'
    },
    link: {
      color: '#52b788',
      textDecoration: 'none',
      fontSize: '14px',
      lineHeight: '1.6',
      cursor: 'pointer',
      transition: 'color 0.2s ease'
    },
    contactItem: {
      fontSize: '14px',
      lineHeight: '1.6',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    copyright: {
      textAlign: 'center',
      paddingTop: '20px',
      borderTop: `1px solid ${darkMode ? '#1b4332' : '#40916c'}`,
      fontSize: '14px',
      opacity: 0.8
    }
  };

  return (
    <footer style={footerStyles.footer}>
      <div style={footerStyles.container}>
        {/* Column 1 - Brand/About */}
        <div style={footerStyles.column}>
          <h3 style={footerStyles.brandTitle}>Greenfield Local Hub</h3>
          <p style={footerStyles.tagline}>
            Supporting local farmers and food producers by connecting them with the community
          </p>
        </div>

        {/* Column 2 - Quick Links */}
        <div style={footerStyles.column}>
          <h4 style={footerStyles.columnTitle}>Quick Links</h4>
          <Link to="/products" style={footerStyles.link}>Browse Products</Link>
          <Link to="/producers" style={footerStyles.link}>Our Producers</Link>
          <Link to="/about" style={footerStyles.link}>About Us</Link>
          <Link to="/register" style={footerStyles.link}>Register</Link>
        </div>

        {/* Column 3 - For Producers */}
        <div style={footerStyles.column}>
          <h4 style={footerStyles.columnTitle}>For Producers</h4>
          <Link to="/register" style={footerStyles.link}>Become a Producer</Link>
          <Link to="/dashboard" style={footerStyles.link}>Producer Dashboard</Link>
          <Link to="/about" style={footerStyles.link}>Guidelines</Link>
          <Link to="/about" style={footerStyles.link}>Support</Link>
        </div>

        {/* Column 4 - Contact Info */}
        <div style={footerStyles.column}>
          <h4 style={footerStyles.columnTitle}>Contact Info</h4>
          <div style={footerStyles.contactItem}>
            📍 123 Market Street, Greenfield, GL1 2AB
          </div>
          <div style={footerStyles.contactItem}>
            📞 01234 567890
          </div>
          <div style={footerStyles.contactItem}>
            ✉️ info@greenfieldlocal.com
          </div>
        </div>
      </div>

      {/* Bottom row - Copyright */}
      <div style={footerStyles.copyright}>
        © 2026 Greenfield Local Hub. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
