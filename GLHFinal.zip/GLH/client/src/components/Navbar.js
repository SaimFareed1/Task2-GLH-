import { Link } from 'react-router-dom';
import { useContext, useState, useEffect } from 'react';
import { ThemeContext } from '../context/ThemeContext';
import { AuthContext } from '../context/AuthContext';
import { FiSun, FiMoon, FiShoppingCart, FiUser, FiMenu, FiX } from 'react-icons/fi';

const Navbar = () => {
  const { darkMode, setDarkMode } = useContext(ThemeContext);
  const { user, isLoggedIn, logout } = useContext(AuthContext);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Check if mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const navLinks = [
    { to: '/', text: 'Home' },
    { to: '/products', text: 'Products' },
    { to: '/producers', text: 'Producers' },
    { to: '/about', text: 'About' },
  ];

  const customerLinks = [
    { to: '/account', text: 'My Account' },
    { to: '/orders', text: 'Order Tracking' },
    { to: '/loyalty', text: 'Loyalty' },
  ];

  return (
    <nav style={{
      backgroundColor: '#2d6a4f',
      color: 'white',
      padding: '16px 0',
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '0 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={{ fontSize: '32px', fontWeight: 'bold' }}>GLH</span>
          <div>
            <div style={{ fontWeight: '600', fontSize: '20px' }}>Greenfield Local Hub</div>
            <div style={{ fontSize: '12px', opacity: 0.9 }}>Fresh • Local • Sustainable</div>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        {!isMobile && (
          <div style={{ display: 'flex', gap: '2rem', fontSize: '17px', fontWeight: '500' }}>
            {navLinks.map(link => (
              <Link 
                key={link.to}
                to={link.to} 
                style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  transition: 'opacity 0.3s ease'
                }}
                onMouseOver={(e) => e.currentTarget.style.opacity = '0.8'}
                onMouseOut={(e) => e.currentTarget.style.opacity = '1'}
              >
                {link.text}
              </Link>
            ))}
          </div>
        )}

        {/* Right Side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          {!isMobile && (
            <>
              <Link to="/basket" style={{ fontSize: '26px', color: 'white', position: 'relative' }}>
                <FiShoppingCart />
              </Link>

              {isLoggedIn ? (
                <>
                  <Link to="/account" style={{ fontSize: '26px', color: 'white' }}>
                    <FiUser />
                  </Link>
                  <button 
                    onClick={logout}
                    style={{
                      backgroundColor: 'white',
                      color: '#2d6a4f',
                      border: 'none',
                      padding: '8px 20px',
                      borderRadius: '6px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      transition: 'background 0.3s ease'
                    }}
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0fdf4'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'white'}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link 
                  to="/login"
                  style={{
                    backgroundColor: 'white',
                    color: '#2d6a4f',
                    border: 'none',
                    padding: '8px 24px',
                    borderRadius: '6px',
                    fontWeight: '600',
                    textDecoration: 'none',
                    transition: 'background 0.3s ease'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f0fdf4'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'white'}
                >
                  Login / Register
                </Link>
              )}

              <button 
                onClick={() => setDarkMode(!darkMode)}
                style={{ fontSize: '26px', color: 'white', background: 'none', border: 'none', cursor: 'pointer' }}
              >
                {darkMode ? <FiSun /> : <FiMoon />}
              </button>
            </>
          )}

          {/* Mobile Menu Button */}
          {isMobile && (
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              style={{ 
                fontSize: '26px', 
                color: 'white', 
                background: 'none', 
                border: 'none', 
                cursor: 'pointer' 
              }}
            >
              {isMobileMenuOpen ? <FiX /> : <FiMenu />}
            </button>
          )}
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            backgroundColor: '#2d6a4f',
            borderBottom: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{ padding: '20px 24px' }}>
              {/* Main Navigation */}
              <div style={{ marginBottom: '20px' }}>
                {navLinks.map(link => (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={() => setIsMobileMenuOpen(false)}
                    style={{
                      display: 'block',
                      color: 'white',
                      textDecoration: 'none',
                      padding: '12px 0',
                      fontSize: '16px',
                      fontWeight: '500',
                      borderBottom: '1px solid rgba(255,255,255,0.1)'
                    }}
                  >
                    {link.text}
                  </Link>
                ))}
              </div>

              {/* Customer Links */}
              {isLoggedIn && (
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ 
                    fontSize: '14px', 
                    color: 'rgba(255,255,255,0.7)', 
                    marginBottom: '10px',
                    textTransform: 'uppercase',
                    fontWeight: '600'
                  }}>
                    Customer
                  </div>
                  {customerLinks.map(link => (
                    <Link
                      key={link.to}
                      to={link.to}
                      onClick={() => setIsMobileMenuOpen(false)}
                      style={{
                        display: 'block',
                        color: 'white',
                        textDecoration: 'none',
                        padding: '12px 0',
                        fontSize: '16px',
                        fontWeight: '500',
                        borderBottom: '1px solid rgba(255,255,255,0.1)'
                      }}
                    >
                      {link.text}
                    </Link>
                  ))}
                </div>
              )}

              {/* Cart and Actions */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'space-between',
                paddingTop: '20px',
                borderTop: '1px solid rgba(255,255,255,0.1)'
              }}>
                <Link 
                  to="/basket"
                  onClick={() => setIsMobileMenuOpen(false)}
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px',
                    color: 'white',
                    textDecoration: 'none',
                    fontSize: '16px',
                    fontWeight: '500'
                  }}
                >
                  <FiShoppingCart size={20} />
                  Basket
                </Link>

                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <button 
                    onClick={() => setDarkMode(!darkMode)}
                    style={{ fontSize: '20px', color: 'white', background: 'none', border: 'none', cursor: 'pointer' }}
                  >
                    {darkMode ? <FiSun /> : <FiMoon />}
                  </button>

                  {isLoggedIn ? (
                    <button 
                      onClick={() => {
                        logout();
                        setIsMobileMenuOpen(false);
                      }}
                      style={{
                        backgroundColor: 'white',
                        color: '#2d6a4f',
                        border: 'none',
                        padding: '8px 16px',
                        borderRadius: '6px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      Logout
                    </button>
                  ) : (
                    <Link 
                      to="/login"
                      onClick={() => setIsMobileMenuOpen(false)}
                      style={{
                        backgroundColor: 'white',
                        color: '#2d6a4f',
                        border: 'none',
                        padding: '8px 16px',
                        borderRadius: '6px',
                        fontWeight: '600',
                        textDecoration: 'none',
                        fontSize: '14px'
                      }}
                    >
                      Login
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;