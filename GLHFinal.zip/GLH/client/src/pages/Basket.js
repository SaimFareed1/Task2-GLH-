import { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

const Basket = () => {
  const { cart, removeFromCart, updateQuantity, clearCart } = useContext(CartContext);
  const navigate = useNavigate();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleQuantityChange = (id, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(id);
    } else {
      updateQuantity(id, newQuantity);
    }
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    navigate('/checkout');
  };

  const handleContinueShopping = () => {
    navigate('/products');
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '42px', color: '#2d6a4f', marginBottom: '10px', fontWeight: '700' }}>Your Basket</h1>
        <p style={{ color: '#52b788', fontSize: '18px' }}>
          {totalItems > 0 ? `${totalItems} item${totalItems > 1 ? 's' : ''} in your basket` : 'Your basket is empty'}
        </p>
      </div>

      {cart.length === 0 ? (
        <div style={{ 
          background: 'white', 
          padding: '80px 40px', 
          borderRadius: '16px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
        }}>
          <div style={{ fontSize: '64px', marginBottom: '20px' }}>🛒</div>
          <h2 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '28px' }}>Your basket is empty</h2>
          <p style={{ color: '#666', marginBottom: '30px', fontSize: '18px', maxWidth: '400px', margin: '0 auto 30px' }}>
            Looks like you haven't added any delicious local produce yet. Start shopping to fill your basket!
          </p>
          <button 
            onClick={handleContinueShopping}
            style={{ 
              background: '#2d6a4f', 
              color: 'white', 
              border: 'none', 
              padding: '15px 30px', 
              borderRadius: '8px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'background 0.3s ease'
            }}
            onMouseOver={(e) => e.currentTarget.style.background = '#40916c'}
            onMouseOut={(e) => e.currentTarget.style.background = '#2d6a4f'}
          >
            Browse Products
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '30px' }}>
          {/* Basket Items */}
          <div style={{ background: 'white', padding: '30px', borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
              Basket Items
            </h2>
            
            <div style={{ display: 'grid', gap: '20px' }}>
              {cart.map(item => (
                <div 
                  key={item.id} 
                  style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center', 
                    padding: '20px',
                    border: '1px solid #e8f5e9',
                    borderRadius: '12px',
                    background: '#fafafa',
                    transition: 'transform 0.3s ease'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                  onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                >
                  <div style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
                    <img 
                      src={item.image || 'https://picsum.photos/id/1015/80/80'} 
                      alt={item.name}
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        borderRadius: '8px', 
                        marginRight: '20px',
                        objectFit: 'cover'
                      }}
                    />
                    <div style={{ flex: 1 }}>
                      <h3 style={{ color: '#2d6a4f', margin: '0 0 8px', fontSize: '18px', fontWeight: '600' }}>
                        {item.name}
                      </h3>
                      <p style={{ color: '#666', margin: '0', fontSize: '14px' }}>
                        {item.category} • {item.unit}
                      </p>
                      <p style={{ color: '#2d6a4f', margin: '8px 0 0', fontSize: '16px', fontWeight: '600' }}>
                        £{item.price.toFixed(2)} per {item.unit}
                      </p>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                    {/* Quantity Controls */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', background: 'white', padding: '5px', borderRadius: '8px', border: '1px solid #ddd' }}>
                      <button 
                        onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                        style={{ 
                          width: '32px', 
                          height: '32px', 
                          borderRadius: '6px', 
                          border: 'none', 
                          background: item.quantity <= 1 ? '#f3f4f6' : '#2d6a4f', 
                          color: item.quantity <= 1 ? '#9ca3af' : 'white',
                          cursor: item.quantity <= 1 ? 'not-allowed' : 'pointer',
                          fontSize: '18px',
                          fontWeight: '600',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        -
                      </button>
                      <span style={{ 
                        minWidth: '40px', 
                        textAlign: 'center', 
                        fontSize: '16px', 
                        fontWeight: '600',
                        color: '#333'
                      }}>
                        {item.quantity}
                      </span>
                      <button 
                        onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        style={{ 
                          width: '32px', 
                          height: '32px', 
                          borderRadius: '6px', 
                          border: 'none', 
                          background: '#2d6a4f', 
                          color: 'white',
                          cursor: 'pointer',
                          fontSize: '18px',
                          fontWeight: '600',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        +
                      </button>
                    </div>

                    {/* Item Total and Remove */}
                    <div style={{ textAlign: 'right', minWidth: '100px' }}>
                      <div style={{ fontSize: '18px', fontWeight: '700', color: '#2d6a4f', marginBottom: '8px' }}>
                        £{(item.price * item.quantity).toFixed(2)}
                      </div>
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        style={{ 
                          background: '#dc2626', 
                          color: 'white', 
                          border: 'none', 
                          padding: '6px 12px', 
                          borderRadius: '6px',
                          fontSize: '14px',
                          cursor: 'pointer',
                          transition: 'background 0.3s ease'
                        }}
                        onMouseOver={(e) => e.currentTarget.style.background = '#b91c1c'}
                        onMouseOut={(e) => e.currentTarget.style.background = '#dc2626'}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Continue Shopping Button */}
            <button 
              onClick={handleContinueShopping}
              style={{ 
                width: '100%', 
                padding: '15px', 
                background: 'transparent', 
                color: '#2d6a4f', 
                border: '2px solid #2d6a4f', 
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer',
                marginTop: '30px',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.background = '#2d6a4f';
                e.currentTarget.style.color = 'white';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#2d6a4f';
              }}
            >
              ← Continue Shopping
            </button>
          </div>

          {/* Order Summary */}
          <div style={{ height: 'fit-content' }}>
            <div style={{ 
              background: 'white', 
              padding: '30px', 
              borderRadius: '16px', 
              boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
              border: '1px solid #e8f5e9',
              position: 'sticky',
              top: '20px'
            }}>
              <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
                Order Summary
              </h2>

              <div style={{ display: 'grid', gap: '15px', marginBottom: '25px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ color: '#666' }}>Subtotal ({totalItems} items)</span>
                  <span style={{ fontSize: '18px', fontWeight: '600', color: '#333' }}>
                    £{total.toFixed(2)}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ color: '#666' }}>Delivery</span>
                  <span style={{ fontSize: '16px', color: '#52b788', fontWeight: '500' }}>
                    Calculated at checkout
                  </span>
                </div>
                <div style={{ 
                  height: '1px', 
                  background: '#e8f5e9', 
                  margin: '10px 0' 
                }}></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f' }}>Total</span>
                  <span style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f' }}>
                    £{total.toFixed(2)}
                  </span>
                </div>
              </div>

              <div style={{ background: '#f0fdf4', padding: '15px', borderRadius: '8px', marginBottom: '25px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '20px' }}>🌱</span>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: '600', color: '#2d6a4f', marginBottom: '2px' }}>
                      Earn {Math.floor(total * 10)} loyalty points
                    </div>
                    <div style={{ fontSize: '12px', color: '#666' }}>
                      10 points per £1 spent
                    </div>
                  </div>
                </div>
              </div>

              <button 
                onClick={handleCheckout}
                style={{ 
                  width: '100%', 
                  padding: '18px', 
                  background: '#2d6a4f', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: '12px', 
                  fontSize: '18px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background 0.3s ease',
                  marginBottom: '15px'
                }}
                onMouseOver={(e) => e.currentTarget.style.background = '#40916c'}
                onMouseOut={(e) => e.currentTarget.style.background = '#2d6a4f'}
              >
                Proceed to Checkout
              </button>

              <button 
                onClick={() => clearCart()}
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  background: 'transparent', 
                  color: '#dc2626', 
                  border: '1px solid #dc2626', 
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.background = '#dc2626';
                  e.currentTarget.style.color = 'white';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = '#dc2626';
                }}
              >
                Clear Basket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Basket;