import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'customer',
    phone: '',
    address: '',
    business_name: '',
    business_desc: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Basic validations
    if (!formData.full_name.trim()) {
      setError("Full name is required");
      return;
    }

    if (!formData.email.trim()) {
      setError("Email is required");
      return;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError("Please enter a valid email address");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (formData.password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    // Producer-specific validations
    if (formData.role === 'producer') {
      if (!formData.business_name.trim()) {
        setError("Business name is required for producers");
        return;
      }
    }

    setLoading(true);

    try {
      console.log('Sending registration data:', formData);
      const response = await axios.post('http://localhost:5001/api/register', formData);
      console.log('Registration response:', response.data);
      
      if (response.data.success) {
        // Auto-login after successful registration
        try {
          const loginResponse = await axios.post('http://localhost:5001/api/login', {
            email: formData.email,
            password: formData.password
          });
          
          if (loginResponse.data.token) {
            // Store token and user info
            localStorage.setItem('token', loginResponse.data.token);
            localStorage.setItem('user', JSON.stringify(loginResponse.data.user));
            
            alert(`Account created successfully as ${formData.role}! You are now logged in.`);
            
            // Redirect based on role
            if (formData.role === 'producer') {
              navigate('/dashboard');   // Producer goes to dashboard
            } else {
              navigate('/account');     // Customer goes to account page
            }
          }
        } catch (loginErr) {
          // If auto-login fails, still show success and redirect to login
          alert(`Account created successfully as ${formData.role}! Please login to continue.`);
          navigate('/login');
        }
      }
    } catch (err) {
      console.error('Registration error:', err);
      console.error('Error response:', err.response);
      console.error('Error data:', err.response?.data);
      
      const errorMessage = err.response?.data?.error || err.message || "Registration failed. Try again.";
      if (errorMessage.includes("Email already exists") || errorMessage.includes("email")) {
        setError("This email is already registered. Please use a different email or login.");
      } else {
        setError(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '520px', margin: '80px auto', padding: '40px 30px', backgroundColor: 'white', borderRadius: '12px', boxShadow: '0 4px 25px rgba(0,0,0,0.1)' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '30px', color: '#166534' }}>Create Your Account</h2>

      {error && <p style={{ color: 'red', textAlign: 'center', marginBottom: '20px' }}>{error}</p>}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333', boxSizing: 'border-box' }}>I want to:</label>
          <select 
            name="role" 
            value={formData.role} 
            onChange={handleChange}
            style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }}
          >
            <option value="customer">Customer - I want to buy local products</option>
            <option value="producer">Producer - I want to sell my products</option>
          </select>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Full Name *</label>
          <input type="text" name="full_name" value={formData.full_name} onChange={handleChange} required style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }} placeholder="Enter your full name" />
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Email *</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }} placeholder="Enter your email" />
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Password (min 8 characters) *</label>
          <input type="password" name="password" value={formData.password} onChange={handleChange} required style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }} placeholder="Create a password" />
        </div>

        <div style={{ marginBottom: '25px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Confirm Password *</label>
          <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} required style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }} placeholder="Confirm your password" />
        </div>

        {formData.role === 'producer' && (
          <>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Business Name *</label>
              <input type="text" name="business_name" value={formData.business_name} onChange={handleChange} required style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', boxSizing: 'border-box' }} placeholder="Enter your business name" />
            </div>
            <div style={{ marginBottom: '25px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500', color: '#333' }}>Business Description</label>
              <textarea name="business_desc" value={formData.business_desc} onChange={handleChange} rows="3" style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', fontSize: '16px', resize: 'vertical', boxSizing: 'border-box' }} placeholder="Tell us about your farm or business..." />
            </div>
          </>
        )}

        <button 
          type="submit" 
          disabled={loading}
          style={{ 
            width: '100%', 
            padding: '16px', 
            backgroundColor: '#166534', 
            color: 'white', 
            border: 'none', 
            borderRadius: '10px', 
            fontSize: '18px', 
            fontWeight: '600',
            cursor: loading ? 'not-allowed' : 'pointer',
            marginTop: '10px'
          }}
        >
          {loading ? 'Creating Account...' : 'Create Account'}
        </button>
      </form>

      <p style={{ textAlign: 'center', marginTop: '25px' }}>
        Already have an account? <Link to="/login" style={{ color: '#166534', fontWeight: '500' }}>Login here</Link>
      </p>
    </div>
  );
};

export default Register;