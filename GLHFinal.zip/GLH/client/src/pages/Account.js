import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Account = () => {
  const [orders, setOrders] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (!user || !user.id) {
      setLoading(false);
      setOrders([]);
      setCurrentUser(null);
      return;
    }

    // Fetch fresh user data and orders
    Promise.all([
      axios.get(`http://localhost:5001/api/users/${user.id}`),
      axios.get(`http://localhost:5001/api/orders/${user.id}`)
    ])
      .then(([userRes, ordersRes]) => {
        setCurrentUser(userRes.data);
        setOrders(ordersRes.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching account data:', err);
        setLoading(false);
      });
  }, [user?.id]);

  const getStatusColor = (status) => {
    const colors = {
      'pending': '#f59e0b',
      'preparing': '#3b82f6', 
      'ready': '#10b981',
      'completed': '#6b7280',
      'delivered': '#10b981'
    };
    return colors[status] || '#6b7280';
  };

  const getStatusText = (status) => {
    const texts = {
      'pending': 'Order Placed',
      'preparing': 'Preparing',
      'ready': 'Ready for Collection',
      'completed': 'Completed',
      'delivered': 'Delivered'
    };
    return texts[status] || status;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const parseOrderItems = (itemsString) => {
    if (!itemsString) return [];
    return itemsString.split(',').map(item => {
      const [productId, quantity, price] = item.split(':');
      return {
        productId: parseInt(productId),
        quantity: parseInt(quantity),
        price: parseFloat(price)
      };
    });
  };

  const getRewards = () => [
    { points: 100, reward: '£5 off your next order', color: '#2d6a4f' },
    { points: 250, reward: 'Free delivery on any order', color: '#40916c' },
    { points: 500, reward: '15% off your whole order', color: '#52b788' }
  ];

  if (loading) {
    return (
      <div style={{ maxWidth: '1000px', margin: '40px auto', padding: '0 30px' }}>
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <p style={{ color: '#666', fontSize: '18px' }}>Loading account information...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1000px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '42px', color: '#2d6a4f', marginBottom: '10px', fontWeight: '700' }}>My Account</h1>
        <p style={{ color: '#52b788', fontSize: '18px' }}>
          Welcome back, {user?.full_name || 'Customer'}!
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '40px' }}>
        {/* Loyalty Points Card */}
        <div style={{ 
          background: 'linear-gradient(135deg, #2d6a4f 0%, #52b788 100%)', 
          padding: '30px', 
          borderRadius: '16px', 
          color: 'white',
          boxShadow: '0 4px 20px rgba(45, 106, 79, 0.3)'
        }}>
          <h3 style={{ fontSize: '24px', marginBottom: '15px', fontWeight: '600' }}>Loyalty Points</h3>
          <div style={{ fontSize: '48px', fontWeight: '700', marginBottom: '10px' }}>
            {currentUser?.points || user?.points || 0}
          </div>
          <p style={{ fontSize: '16px', opacity: 0.9, marginBottom: '20px' }}>
            Earn 10 points for every £1 spent
          </p>
          <button 
            style={{ 
              background: 'white', 
              color: '#2d6a4f', 
              border: 'none', 
              padding: '12px 24px', 
              borderRadius: '8px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'transform 0.3s ease'
            }}
            onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
            onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            View Rewards
          </button>
        </div>

        {/* Account Summary */}
        <div style={{ 
          background: 'white', 
          padding: '30px', 
          borderRadius: '16px', 
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
          border: '1px solid #e8f5e9'
        }}>
          <h3 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '20px', fontWeight: '600' }}>Account Summary</h3>
          <div style={{ display: 'grid', gap: '15px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#666' }}>Total Orders</span>
              <span style={{ fontSize: '20px', fontWeight: '600', color: '#2d6a4f' }}>{orders.length}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#666' }}>Member Since</span>
              <span style={{ fontSize: '16px', color: '#333' }}>January 2024</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#666' }}>Account Type</span>
              <span style={{ 
                background: '#e8f5e9', 
                color: '#2d6a4f', 
                padding: '4px 12px', 
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600'
              }}>
                Customer
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Available Rewards */}
      <div style={{ marginBottom: '40px' }}>
        <h2 style={{ color: '#2d6a4f', fontSize: '28px', marginBottom: '20px', fontWeight: '600' }}>Available Rewards</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px' }}>
          {getRewards().map((reward, index) => (
            <div 
              key={index}
              style={{ 
                background: 'white', 
                padding: '25px', 
                borderRadius: '12px', 
                border: '2px solid #e8f5e9',
                textAlign: 'center',
                transition: 'transform 0.3s ease, border-color 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-3px)';
                e.currentTarget.style.borderColor = reward.color;
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.borderColor = '#e8f5e9';
              }}
            >
              <div style={{ fontSize: '32px', fontWeight: '700', color: reward.color, marginBottom: '10px' }}>
                {reward.points}
              </div>
              <div style={{ color: '#666', marginBottom: '5px' }}>points</div>
              <div style={{ color: '#333', fontWeight: '500', marginTop: '10px' }}>
                {reward.reward}
              </div>
              <button 
                disabled={(currentUser?.points || user?.points || 0) < reward.points}
                style={{ 
                  marginTop: '15px',
                  padding: '10px 20px',
                  background: (currentUser?.points || user?.points || 0) >= reward.points ? reward.color : '#e5e7eb',
                  color: (currentUser?.points || user?.points || 0) >= reward.points ? 'white' : '#9ca3af',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: (currentUser?.points || user?.points || 0) >= reward.points ? 'pointer' : 'not-allowed',
                  transition: 'opacity 0.3s ease'
                }}
              >
                {(currentUser?.points || user?.points || 0) >= reward.points ? 'Redeem' : `${reward.points - (currentUser?.points || user?.points || 0)} points needed`}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Order History */}
      <div>
        <h2 style={{ color: '#2d6a4f', fontSize: '28px', marginBottom: '20px', fontWeight: '600' }}>Order History</h2>
        
        {orders.length === 0 ? (
          <div style={{ 
            background: 'white', 
            padding: '60px 30px', 
            borderRadius: '16px', 
            textAlign: 'center',
            border: '1px solid #e8f5e9'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '20px' }}>🛒</div>
            <h3 style={{ color: '#2d6a4f', marginBottom: '10px' }}>No orders yet</h3>
            <p style={{ color: '#666', marginBottom: '20px' }}>Start shopping to see your order history here</p>
            <button 
              style={{ 
                background: '#2d6a4f', 
                color: 'white', 
                border: 'none', 
                padding: '12px 24px', 
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              Browse Products
            </button>
          </div>
        ) : (
          <div style={{ display: 'grid', gap: '20px' }}>
            {orders.map(order => (
              <div 
                key={order.id} 
                style={{ 
                  background: 'white', 
                  padding: '25px', 
                  borderRadius: '12px', 
                  border: '1px solid #e8f5e9',
                  transition: 'transform 0.3s ease'
                }}
                onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div>
                    <h4 style={{ color: '#2d6a4f', fontSize: '20px', marginBottom: '8px' }}>
                      Order #{order.id}
                    </h4>
                    <p style={{ color: '#666', margin: '0', fontSize: '14px' }}>
                      {formatDate(order.created_at)}
                    </p>
                    <p style={{ color: '#666', margin: '5px 0 0', fontSize: '14px' }}>
                      {order.order_type === 'delivery' ? '🚚 Delivery' : '🏪 Collection'}
                      {order.order_type === 'delivery' && order.delivery_address && ` to ${order.delivery_address}`}
                      {order.order_type === 'collection' && order.collection_time && ` at ${order.collection_time}`}
                    </p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '8px' }}>
                      £{order.total.toFixed(2)}
                    </div>
                    <span style={{ 
                      background: getStatusColor(order.status), 
                      color: 'white', 
                      padding: '6px 12px', 
                      borderRadius: '20px',
                      fontSize: '12px',
                      fontWeight: '600'
                    }}>
                      {getStatusText(order.status)}
                    </span>
                  </div>
                </div>

                {order.items && (
                  <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '8px' }}>
                    <h5 style={{ color: '#2d6a4f', margin: '0 0 10px', fontSize: '14px', fontWeight: '600' }}>
                      Order Items
                    </h5>
                    <div style={{ display: 'grid', gap: '8px' }}>
                      {parseOrderItems(order.items).map((item, index) => (
                        <div key={index} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                          <span style={{ color: '#666' }}>Item #{item.productId}</span>
                          <span style={{ color: '#333' }}>Qty: {item.quantity} × £{item.price.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Account;