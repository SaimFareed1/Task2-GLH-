import React, { useState, useContext, useEffect } from 'react';
import { ProductContext } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const Dashboard = () => {
  const { products, addProduct, updateProduct } = useContext(ProductContext);
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('products');
  const [orders, setOrders] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [myProducts, setMyProducts] = useState([]);
  const [producerInfo, setProducerInfo] = useState(null);
  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    category: 'Vegetables',
    unit: 'kg'
  });

  // Get producer info for the logged-in user
  useEffect(() => {
    console.log('=== DASHBOARD DEBUGGING ===');
    console.log('User data from context:', user);
    console.log('User ID:', user?.id);
    console.log('User role:', user?.role);
    console.log('User producer_id:', user?.producer_id);
    console.log('User business_name:', user?.business_name);
    
    // Check localStorage
    const token = localStorage.getItem('token');
    const userStorage = localStorage.getItem('user');
    console.log('Token from localStorage:', token);
    console.log('User from localStorage:', userStorage ? JSON.parse(userStorage) : null);
    
    if (user && user.role === 'producer' && user.producer_id) {
      console.log('Producer found! Using producer_id:', user.producer_id);
      
      // Create producer info from user data (no API call needed)
      const producerData = {
        id: user.producer_id,
        user_id: user.id,
        farm_name: user.business_name || user.full_name,
        location: user.address || '',
        methods_description: user.business_desc || 'Local producer',
        logo_url: 'https://picsum.photos/id/999/100/100',
        full_name: user.full_name,
        business_name: user.business_name,
        business_desc: user.business_desc
      };
      
      console.log('Created producer data:', producerData);
      setProducerInfo(producerData);
      
      // Fetch producer's products using the producer_id
      axios.get(`http://localhost:5001/api/products/producer/${user.producer_id}`)
        .then(res => {
          console.log('Products API response:', res.data);
          setMyProducts(res.data);
        })
        .catch(err => {
          console.error('Error fetching products:', err);
          setMyProducts([]);
        });
    } else {
      console.log('No producer data found - user:', user);
      setMyProducts([]);
      setProducerInfo(null);
    }
    console.log('=== END DASHBOARD DEBUGGING ===');
  }, [user]);

  useEffect(() => {
    if (activeTab === 'orders' && producerInfo) {
      axios.get(`http://localhost:5001/api/producer/${producerInfo.id}/orders`)
        .then(res => setOrders(res.data))
        .catch(err => console.error('Error fetching orders:', err));
    }
  }, [activeTab, producerInfo]);

  const handleAddProduct = () => {
    console.log('Adding product:', newProduct);
    console.log('Producer info:', producerInfo);
    
    // Check required fields
    if (!newProduct.name || !newProduct.price || !newProduct.stock) {
      alert("Please fill Product Name, Price and Stock");
      return;
    }

    // Check if producer info is available
    if (!producerInfo) {
      alert("Producer information not loaded. Please wait a moment and try again.");
      return;
    }

    // Validate numeric values
    if (isNaN(parseFloat(newProduct.price)) || parseFloat(newProduct.price) <= 0) {
      alert("Please enter a valid price greater than 0");
      return;
    }

    if (isNaN(parseInt(newProduct.stock)) || parseInt(newProduct.stock) < 0) {
      alert("Please enter a valid stock quantity (0 or greater)");
      return;
    }

    const productData = {
      name: newProduct.name,
      description: newProduct.description || "No description provided by producer.",
      price: parseFloat(newProduct.price),
      stock: parseInt(newProduct.stock),
      category: newProduct.category,
      unit: newProduct.unit,
      image_url: "https://picsum.photos/id/1015/600/400",
      producer_id: producerInfo.id
    };

    console.log('Sending product data:', productData);

    axios.post('http://localhost:5001/api/products', productData)
    .then(res => {
      console.log('Product added successfully:', res.data);
      // Add the new product to the local state
      setMyProducts([...myProducts, res.data]);
      setNewProduct({ name: '', description: '', price: '', stock: '', category: 'Vegetables', unit: 'kg' });
      setShowAddModal(false);
      alert("Product added successfully!");
    })
    .catch(err => {
      console.error('Error adding product:', err);
      console.error('Error response:', err.response?.data);
      const errorMessage = err.response?.data?.error || err.message || "Failed to add product. Please try again.";
      alert(errorMessage);
    });
  };

  const updateStock = (id, newStock) => {
    const product = myProducts.find(p => p.id === id);
    if (product) {
      axios.put(`http://localhost:5001/api/products/${id}`, {
        ...product,
        stock: parseInt(newStock) || 0
      }).then(() => {
        // Update local state
        setMyProducts(myProducts.map(p => 
          p.id === id ? { ...p, stock: parseInt(newStock) || 0 } : p
        ));
      }).catch(err => console.error('Error updating stock:', err));
    }
  };

  const updatePrice = (id, newPrice) => {
    const product = myProducts.find(p => p.id === id);
    if (product) {
      axios.put(`http://localhost:5001/api/products/${id}`, {
        ...product,
        price: parseFloat(newPrice) || 0
      }).then(() => {
        // Update local state
        setMyProducts(myProducts.map(p => 
          p.id === id ? { ...p, price: parseFloat(newPrice) || 0 } : p
        ));
      }).catch(err => console.error('Error updating price:', err));
    }
  };

  const updateOrderStatus = (orderId, newStatus) => {
    axios.put(`http://localhost:5001/api/orders/${orderId}/status`, { status: newStatus })
      .then(() => {
        setOrders(orders.map(order => 
          order.id === orderId ? { ...order, status: newStatus } : order
        ));
      })
      .catch(err => console.error('Error updating order status:', err));
  };

  const getStatusColor = (status) => {
    const colors = {
      'pending': '#f59e0b',
      'preparing': '#3b82f6', 
      'ready': '#10b981',
      'completed': '#6b7280',
      'delivered': '#10b981'
    };
    return colors[status] || '#6b7280';
  };

  const getAvailabilityBadge = (stock) => {
    if (stock === 0) return { text: 'Out of Stock', color: '#dc2626' };
    if (stock < 10) return { text: 'Low Stock', color: '#f59e0b' };
    return { text: 'In Stock', color: '#10b981' };
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '42px', color: '#2d6a4f', marginBottom: '10px', fontWeight: '700' }}>Producer Dashboard</h1>
        <p style={{ color: '#52b788', fontSize: '18px' }}>Manage your products, view orders and track your sales</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '30px', borderBottom: '2px solid #e8f5e9' }}>
        {['products', 'orders'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              padding: '15px 30px',
              background: activeTab === tab ? '#2d6a4f' : 'transparent',
              color: activeTab === tab ? 'white' : '#2d6a4f',
              border: 'none',
              borderRadius: '8px 8px 0 0',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            {tab === 'products' ? 'My Products' : 'View Orders'}
          </button>
        ))}
      </div>

      {activeTab === 'products' && (
        <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px' }}>Product Management</h2>
            <button 
              onClick={() => setShowAddModal(true)}
              disabled={!producerInfo}
              style={{ 
                padding: '12px 24px', 
                backgroundColor: producerInfo ? '#2d6a4f' : '#94a3b8', 
                color: 'white', 
                border: 'none', 
                borderRadius: '8px', 
                fontWeight: '600', 
                cursor: producerInfo ? 'pointer' : 'not-allowed',
                transition: 'background 0.3s ease',
                opacity: producerInfo ? 1 : 0.7
              }}
              onMouseOver={(e) => {
                if (producerInfo) e.currentTarget.style.background = '#40916c';
              }}
              onMouseOut={(e) => {
                if (producerInfo) e.currentTarget.style.background = '#2d6a4f';
              }}
            >
              {producerInfo ? '+ Add New Product' : 'Loading Producer Info...'}
            </button>
          </div>

          {myProducts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 20px' }}>
              <p style={{ color: '#666', fontSize: '18px' }}>
                {producerInfo ? "You haven't added any products yet. Click 'Add New Product' to get started." : "Loading your producer information..."}
              </p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid #e8f5e9' }}>
                    <th style={{ textAlign: 'left', padding: '15px', color: '#2d6a4f' }}>Product</th>
                    <th style={{ textAlign: 'center', padding: '15px', color: '#2d6a4f' }}>Category</th>
                    <th style={{ textAlign: 'center', padding: '15px', color: '#2d6a4f' }}>Price</th>
                    <th style={{ textAlign: 'center', padding: '15px', color: '#2d6a4f' }}>Stock</th>
                    <th style={{ textAlign: 'center', padding: '15px', color: '#2d6a4f' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {myProducts.map(product => {
                    const availability = getAvailabilityBadge(product.stock);
                    return (
                      <tr key={product.id} style={{ borderBottom: '1px solid #e8f5e9' }}>
                        <td style={{ padding: '20px 15px' }}>
                          <div>
                            <div style={{ fontWeight: '600', color: '#333', marginBottom: '5px' }}>{product.name}</div>
                            <div style={{ fontSize: '14px', color: '#666' }}>{product.unit}</div>
                          </div>
                        </td>
                        <td style={{ textAlign: 'center', padding: '20px 15px', color: '#666' }}>
                          {product.category}
                        </td>
                        <td style={{ textAlign: 'center', padding: '20px 15px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                            <span style={{ color: '#333' }}>£</span>
                            <input 
                              type="number" 
                              step="0.01"
                              value={product.price}
                              onChange={(e) => updatePrice(product.id, e.target.value)}
                              style={{ 
                                width: '80px', 
                                padding: '8px', 
                                textAlign: 'center', 
                                border: '1px solid #ddd', 
                                borderRadius: '6px',
                                fontSize: '14px'
                              }}
                            />
                          </div>
                        </td>
                        <td style={{ textAlign: 'center', padding: '20px 15px' }}>
                          <input 
                            type="number" 
                            value={product.stock}
                            onChange={(e) => updateStock(product.id, e.target.value)}
                            style={{ 
                              width: '70px', 
                              padding: '8px', 
                              textAlign: 'center', 
                              border: '1px solid #ddd', 
                              borderRadius: '6px',
                              fontSize: '14px'
                            }}
                          />
                        </td>
                        <td style={{ textAlign: 'center', padding: '20px 15px' }}>
                          <span style={{ 
                            background: availability.color, 
                            color: 'white', 
                            padding: '4px 12px', 
                            borderRadius: '20px',
                            fontSize: '12px',
                            fontWeight: '600'
                          }}>
                            {availability.text}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'orders' && (
        <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
          <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '30px' }}>Customer Orders</h2>
          
          {orders.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 20px' }}>
              <p style={{ color: '#666', fontSize: '18px' }}>No orders yet</p>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: '20px' }}>
              {orders.map(order => (
                <div key={order.id} style={{ 
                  border: '1px solid #e8f5e9', 
                  borderRadius: '12px', 
                  padding: '20px',
                  background: '#fafafa'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                    <div>
                      <h4 style={{ color: '#2d6a4f', margin: '0' }}>Order #{order.id}</h4>
                      <p style={{ color: '#666', margin: '5px 0 0', fontSize: '14px' }}>
                        {order.customer_name} • {order.created_at}
                      </p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '20px', fontWeight: '600', color: '#2d6a4f' }}>
                        £{order.total.toFixed(2)}
                      </div>
                      <div style={{ marginTop: '8px' }}>
                        <span style={{ 
                          background: getStatusColor(order.status), 
                          color: 'white', 
                          padding: '4px 12px', 
                          borderRadius: '20px',
                          fontSize: '12px',
                          fontWeight: '600'
                        }}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
                    <select 
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                      style={{ 
                        flex: 1, 
                        padding: '8px', 
                        border: '1px solid #ddd', 
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    >
                      <option value="pending">Pending</option>
                      <option value="preparing">Preparing</option>
                      <option value="ready">Ready</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add Product Modal */}
      {showAddModal && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div style={{ backgroundColor: 'white', padding: '30px', borderRadius: '16px', width: '500px', maxHeight: '90vh', overflowY: 'auto' }}>
            <h3 style={{ color: '#2d6a4f', marginBottom: '20px' }}>Add New Product</h3>
            
            <input 
              type="text" 
              placeholder="Product Name *" 
              value={newProduct.name}
              onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
              style={{ width: '100%', padding: '12px', margin: '12px 0', borderRadius: '8px', border: '1px solid #ddd' }}
            />
            
            <textarea 
              placeholder="Description (optional)" 
              value={newProduct.description}
              onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
              rows="3"
              style={{ width: '100%', padding: '12px', margin: '12px 0', borderRadius: '8px', border: '1px solid #ddd' }}
            />

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
              <input 
                type="number" 
                placeholder="Price (£) *" 
                value={newProduct.price}
                onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                style={{ padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }}
              />
              <input 
                type="number" 
                placeholder="Initial Stock *" 
                value={newProduct.stock}
                onChange={(e) => setNewProduct({...newProduct, stock: e.target.value})}
                style={{ padding: '12px', borderRadius: '8px', border: '1px solid #ddd' }}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
              <select 
                value={newProduct.category}
                onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
                style={{ padding: '12px', borderRadius: '8px', border: '1px solid #ddd', margin: '12px 0' }}
              >
                <option value="Vegetables">Vegetables</option>
                <option value="Bakery">Bakery</option>
                <option value="Dairy">Dairy</option>
                <option value="Eggs">Eggs</option>
                <option value="Pantry">Pantry</option>
              </select>
              <select 
                value={newProduct.unit}
                onChange={(e) => setNewProduct({...newProduct, unit: e.target.value})}
                style={{ padding: '12px', borderRadius: '8px', border: '1px solid #ddd', margin: '12px 0' }}
              >
                <option value="kg">kg</option>
                <option value="loaf">loaf</option>
                <option value="dozen">dozen</option>
                <option value="liter">liter</option>
                <option value="jar">jar</option>
                <option value="set">set</option>
              </select>
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '20px' }}>
              <button onClick={handleAddProduct} style={{ 
                flex: 1, 
                padding: '14px', 
                backgroundColor: '#2d6a4f', 
                color: 'white', 
                border: 'none', 
                borderRadius: '10px', 
                fontWeight: '600',
                cursor: 'pointer'
              }}>
                Add Product
              </button>
              <button onClick={() => setShowAddModal(false)} style={{ 
                flex: 1, 
                padding: '14px', 
                backgroundColor: '#f3f4f6', 
                border: 'none', 
                borderRadius: '10px',
                cursor: 'pointer'
              }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;