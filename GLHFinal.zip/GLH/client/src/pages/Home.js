import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { CartContext } from '../context/CartContext';
import { ThemeContext } from '../context/ThemeContext';

const Home = () => {
  const { addToCart } = useContext(CartContext);
  const { darkMode } = useContext(ThemeContext);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch products from API to get real images
    setLoading(true);
    axios.get('http://localhost:5001/api/products')
      .then(res => {
        console.log('API products received:', res.data.length);
        // Take first 6 products as featured products
        const featured = res.data.slice(0, 6);
        setFeaturedProducts(featured);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching products:', err);
        // Fallback to hardcoded products if API fails
        const fallbackProducts = [
          { id: 1, name: 'Organic Mixed Salad Leaves', price: 4.00, description: 'Fresh organic salad mix including lettuce, rocket, and mizuna', image_url: 'https://picsum.photos/id/1015/400/300', stock: 30, category: 'Vegetables', unit: '500g', availability: 'in_stock' },
          { id: 2, name: 'Heritage Tomatoes', price: 3.50, description: 'Heirloom variety tomatoes in various colors, vine-ripened', image_url: 'https://picsum.photos/id/292/400/300', stock: 20, category: 'Vegetables', unit: '800g', availability: 'in_stock' },
          { id: 3, name: 'Sourdough Loaf', price: 2.50, description: 'Traditional sourdough made with heritage grains, long fermentation', image_url: 'https://picsum.photos/id/201/400/300', stock: 45, category: 'Bakery', unit: '200g', availability: 'in_stock' },
          { id: 4, name: 'Free Range Eggs (6)', price: 2.80, description: 'Large brown eggs from happy hens, 6 per pack', image_url: 'https://picsum.photos/id/701/400/300', stock: 60, category: 'Eggs', unit: 'pack', availability: 'in_stock' },
          { id: 5, name: 'Raw Cow Milk Cheese', price: 5.50, description: 'Artisan cheese made from raw cow milk, aged 3 months', image_url: 'https://picsum.photos/id/401/400/300', stock: 15, category: 'Dairy', unit: '250g', availability: 'low_stock' },
          { id: 6, name: 'Artisan Butter', price: 3.20, description: 'Rich, creamy butter from grass-fed cows', image_url: 'https://picsum.photos/id/501/400/300', stock: 25, category: 'Dairy', unit: '200g', availability: 'in_stock' }
        ];
        setFeaturedProducts(fallbackProducts);
        setLoading(false);
      });
  }, []);

  const getAvailabilityBadge = (stock, availability) => {
    if (stock === 0 || availability === 'out_of_stock') {
      return { text: 'Out of Stock', color: '#dc2626', bgColor: '#fef2f2' };
    }
    if (stock < 10 || availability === 'low_stock') {
      return { text: 'Low Stock', color: '#f59e0b', bgColor: '#fffbeb' };
    }
    return { text: 'In Stock', color: '#10b981', bgColor: '#f0fdf4' };
  };

  const benefits = [
    {
      icon: '🌱',
      title: 'Fresh & Local',
      description: 'Produce harvested within 24 hours of delivery'
    },
    {
      icon: '👨‍🌾',
      title: 'Support Local Farmers',
      description: 'Direct relationships with sustainable family farms'
    },
    {
      icon: '🌍',
      title: 'Eco-Friendly',
      description: 'Reduced food miles and sustainable farming practices'
    },
    {
      icon: '🏆',
      title: 'Quality Guaranteed',
      description: 'Hand-picked premium produce with full traceability'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Regular Customer',
      content: 'The quality of produce is exceptional. I love knowing exactly where my food comes from!',
      rating: 5
    },
    {
      name: 'Mike Chen',
      role: 'Home Chef',
      content: 'Fresh ingredients make all the difference in my cooking. GLH delivers every time.',
      rating: 5
    },
    {
      name: 'Emma Wilson',
      role: 'Parent',
      content: 'Great value for money and my kids love the fresh vegetables. Supporting local feels good.',
      rating: 5
    }
  ];

  const renderStars = (rating) => {
    return Array(5).fill(0).map((_, i) => (
      <span key={i} style={{ color: i < rating ? '#fbbf24' : '#e5e7eb', fontSize: '16px' }}>
        ★
      </span>
    ));
  };

  return (
    <div style={{ backgroundColor: darkMode ? '#1a1a1a' : '#f8fafb' }}>
      {/* Hero Section */}
      <section style={{ 
        background: `linear-gradient(rgba(45, 106, 79, 0.8), rgba(45, 106, 79, 0.8)), url("https://images.unsplash.com/photo-1464226184884-fa280b87c399")`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        padding: '120px 30px 80px',
        color: 'white',
        position: 'relative',
        overflow: 'hidden'
      }}>
        
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '600px' }}>
            <h1 style={{ 
              fontSize: '64px', 
              fontWeight: '800', 
              marginBottom: '24px',
              lineHeight: '1.1'
            }}>
              Fresh Local Produce, Delivered to Your Door
            </h1>
            <p style={{ 
              fontSize: '22px', 
              marginBottom: '40px', 
              opacity: 0.95,
              lineHeight: '1.6'
            }}>
              Connect directly with sustainable local farmers and enjoy the freshest, 
              most flavorful produce our community has to offer.
            </p>
            
            <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
              <Link 
                to="/products"
                style={{
                  backgroundColor: 'white',
                  color: '#2d6a4f',
                  padding: '16px 32px',
                  borderRadius: '12px',
                  fontSize: '18px',
                  fontWeight: '600',
                  textDecoration: 'none',
                  display: 'inline-block',
                  transition: 'transform 0.3s ease',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.15)'
                }}
                onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                Browse Products
              </Link>
              <Link 
                to="/producers"
                style={{
                  backgroundColor: 'transparent',
                  color: 'white',
                  border: '2px solid white',
                  padding: '16px 32px',
                  borderRadius: '12px',
                  fontSize: '18px',
                  fontWeight: '600',
                  textDecoration: 'none',
                  display: 'inline-block',
                  transition: 'all 0.3s ease'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.backgroundColor = 'white';
                  e.currentTarget.style.color = '#2d6a4f';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.color = 'white';
                }}
              >
                Meet Our Producers
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section style={{ 
        backgroundColor: '#2d6a4f', 
        padding: '40px 30px',
        color: 'white'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '40px' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '48px', fontWeight: '700', marginBottom: '8px' }}>25+</div>
              <div style={{ fontSize: '16px', opacity: 0.9 }}>Local Producers</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '48px', fontWeight: '700', marginBottom: '8px' }}>100+</div>
              <div style={{ fontSize: '16px', opacity: 0.9 }}>Fresh Products</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '48px', fontWeight: '700', marginBottom: '8px' }}>500+</div>
              <div style={{ fontSize: '16px', opacity: 0.9 }}>Happy Customers</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '48px', fontWeight: '700', marginBottom: '8px' }}>0</div>
              <div style={{ fontSize: '16px', opacity: 0.9 }}>Food Miles</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section style={{ padding: '80px 30px', backgroundColor: darkMode ? '#2d2d2d' : 'white' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{ fontSize: '42px', color: darkMode ? '#e5e7eb' : '#2d6a4f', marginBottom: '16px', fontWeight: '700' }}>
              Featured Products
            </h2>
            <p style={{ fontSize: '18px', color: darkMode ? '#e5e7eb' : '#666', maxWidth: '600px', margin: '0 auto' }}>
              Hand-picked selections from our local producers this week
            </p>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '60px 20px' }}>
              <p style={{ color: darkMode ? '#e5e7eb' : '#666', fontSize: '18px' }}>Loading fresh products...</p>
            </div>
          ) : (
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
              gap: '30px',
              marginBottom: '40px'
            }}>
              {featuredProducts.map(product => {
                const availability = getAvailabilityBadge(product.stock, product.availability);
                const isOutOfStock = product.stock === 0 || product.availability === 'out_of_stock';
                
                return (
                  <div 
                    key={product.id}
                    style={{
                      backgroundColor: darkMode ? '#2d2d2d' : 'white',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      boxShadow: darkMode ? '0 4px 20px rgba(0,0,0,0.3)' : '0 4px 20px rgba(0,0,0,0.08)',
                      border: darkMode ? '1px solid #404040' : '1px solid #e8f5e9',
                      transition: 'transform 0.3s ease',
                      cursor: 'pointer'
                    }}
                    onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
                    onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
                  >
                    <div style={{ position: 'relative' }}>
                      <img 
                        src={product.image_url || 'https://picsum.photos/id/1015/400/250'} 
                        alt={product.name} 
                        style={{ 
                          width: '100%', 
                          height: '160px', 
                          objectFit: 'cover',
                          borderRadius: '8px 8px 0 0'
                        }}
                        onError={(e) => {
                          e.target.style.display = 'none';
                          const placeholder = document.createElement('div');
                          placeholder.style.cssText = 'width: 100%; height: 160px; display: flex; align-items: center; justify-content: center; font-size: 48px; background: #f0fdf4; border-radius: 8px 8px 0 0;';
                          placeholder.textContent = product.category === 'Vegetables' ? '🥕' : product.category === 'Bakery' ? '🍞' : product.category === 'Dairy' ? '🥛' : product.category === 'Eggs' ? '🥚' : '🌿';
                          e.target.parentNode.insertBefore(placeholder, e.target);
                        }}
                      />
                      {availability.text !== 'In Stock' && (
                        <div style={{
                          position: 'absolute',
                          top: '15px',
                          right: '15px',
                          background: availability.color,
                          color: 'white',
                          padding: '6px 12px',
                          borderRadius: '20px',
                          fontSize: '12px',
                          fontWeight: '600',
                          textTransform: 'uppercase'
                        }}>
                          {availability.text}
                        </div>
                      )}
                    </div>
                    
                    <div style={{ padding: '25px' }}>
                      <div style={{ marginBottom: '15px' }}>
                        <span style={{ 
                          background: darkMode ? '#2d6a4f' : '#f0fdf4', 
                          color: darkMode ? '#f0fdf4' : '#2d6a4f', 
                          padding: '4px 10px', 
                          borderRadius: '15px',
                          fontSize: '12px',
                          fontWeight: '600',
                          textTransform: 'uppercase'
                        }}>
                          {product.category}
                        </span>
                      </div>
                      
                      <h3 style={{ 
                        fontSize: '20px', 
                        marginBottom: '10px', 
                        fontWeight: '700',
                        color: darkMode ? '#52b788' : '#2d6a4f',
                        lineHeight: '1.3'
                      }}>
                        {product.name}
                      </h3>
                      
                      <p style={{ 
                        color: darkMode ? '#e5e7eb' : '#666', 
                        fontSize: '15px', 
                        marginBottom: '20px', 
                        lineHeight: '1.5',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden'
                      }}>
                        {product.description}
                      </p>

                      <div style={{ 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'center',
                        marginBottom: '20px' 
                      }}>
                        <div>
                          <div style={{ 
                            fontSize: '24px', 
                            fontWeight: '700', 
                            color: darkMode ? '#52b788' : '#2d6a4f',
                            lineHeight: '1'
                          }}>
                            £{product.price.toFixed(2)}
                          </div>
                          <div style={{ 
                            fontSize: '14px', 
                            color: darkMode ? '#e5e7eb' : '#666',
                            marginTop: '2px'
                          }}>
                            per {product.unit}
                          </div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', gap: '10px' }}>
                        <Link 
                          to={`/product/${product.id}`}
                          style={{
                            flex: 1,
                            textAlign: 'center',
                            padding: '12px',
                            backgroundColor: 'transparent',
                            color: '#2d6a4f',
                            border: '2px solid #2d6a4f',
                            borderRadius: '8px',
                            fontWeight: '600',
                            textDecoration: 'none',
                            fontSize: '14px',
                            transition: 'all 0.3s ease'
                          }}
                          onMouseOver={(e) => {
                            e.currentTarget.style.backgroundColor = '#2d6a4f';
                            e.currentTarget.style.color = 'white';
                          }}
                          onMouseOut={(e) => {
                            e.currentTarget.style.backgroundColor = 'transparent';
                            e.currentTarget.style.color = '#2d6a4f';
                          }}
                        >
                          View Details
                        </Link>
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            if (!isOutOfStock) {
                              addToCart(product);
                            }
                          }}
                          disabled={isOutOfStock}
                          style={{
                            flex: 1,
                            padding: '12px',
                            backgroundColor: isOutOfStock ? '#e5e7eb' : '#2d6a4f',
                            color: isOutOfStock ? '#9ca3af' : 'white',
                            border: 'none',
                            borderRadius: '8px',
                            fontWeight: '600',
                            fontSize: '14px',
                            cursor: isOutOfStock ? 'not-allowed' : 'pointer',
                            transition: 'background 0.3s ease'
                          }}
                          onMouseOver={(e) => {
                            if (!isOutOfStock) {
                              e.currentTarget.style.backgroundColor = '#40916c';
                            }
                          }}
                          onMouseOut={(e) => {
                            if (!isOutOfStock) {
                              e.currentTarget.style.backgroundColor = '#2d6a4f';
                            }
                          }}
                        >
                          {isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div style={{ textAlign: 'center' }}>
            <Link 
              to="/products"
              style={{
                backgroundColor: 'transparent',
                color: '#2d6a4f',
                border: '2px solid #2d6a4f',
                padding: '12px 24px',
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                textDecoration: 'none',
                display: 'inline-block',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.backgroundColor = '#2d6a4f';
                e.currentTarget.style.color = 'white';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.color = '#2d6a4f';
              }}
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Why Buy Local */}
      <section style={{ 
        backgroundColor: darkMode ? '#2d2d2d' : '#f0fdf4', 
        padding: '80px 30px'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{ fontSize: '42px', color: darkMode ? '#e5e7eb' : '#2d6a4f', marginBottom: '16px', fontWeight: '700' }}>
              Why Buy Local?
            </h2>
            <p style={{ fontSize: '18px', color: darkMode ? '#e5e7eb' : '#666', maxWidth: '600px', margin: '0 auto' }}>
              Discover the benefits of supporting your local community and enjoying fresher, more sustainable food
            </p>
          </div>

          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', 
            gap: '40px' 
          }}>
            {benefits.map((benefit, index) => (
              <div key={index} style={{ textAlign: 'center' }}>
                <div style={{ 
                  fontSize: '64px', 
                  marginBottom: '20px',
                  lineHeight: '1'
                }}>
                  {benefit.icon}
                </div>
                <h3 style={{ 
                  fontSize: '24px', 
                  color: darkMode ? '#52b788' : '#2d6a4f', 
                  marginBottom: '12px',
                  fontWeight: '700'
                }}>
                  {benefit.title}
                </h3>
                <p style={{ 
                  color: darkMode ? '#e5e7eb' : '#666', 
                  fontSize: '16px',
                  lineHeight: '1.6'
                }}>
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section style={{ padding: '80px 30px', backgroundColor: darkMode ? '#2d2d2d' : 'white' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{ fontSize: '42px', color: darkMode ? '#e5e7eb' : '#2d6a4f', marginBottom: '16px', fontWeight: '700' }}>
              What Our Customers Say
            </h2>
            <p style={{ fontSize: '18px', color: darkMode ? '#e5e7eb' : '#666', maxWidth: '600px', margin: '0 auto' }}>
              Join hundreds of satisfied customers who enjoy fresh, local produce
            </p>
          </div>

          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
            gap: '30px' 
          }}>
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                style={{
                  backgroundColor: darkMode ? '#2d2d2d' : 'white',
                  padding: '30px',
                  borderRadius: '16px',
                  boxShadow: darkMode ? '0 4px 20px rgba(0,0,0,0.3)' : '0 4px 20px rgba(0,0,0,0.08)',
                  border: darkMode ? '1px solid #404040' : '1px solid #e8f5e9'
                }}
              >
                <div style={{ marginBottom: '20px' }}>
                  {renderStars(testimonial.rating)}
                </div>
                <p style={{ 
                  color: darkMode ? '#e5e7eb' : '#333', 
                  fontSize: '16px',
                  lineHeight: '1.6',
                  marginBottom: '20px',
                  fontStyle: 'italic'
                }}>
                  "{testimonial.content}"
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ 
                    width: '48px', 
                    height: '48px', 
                    borderRadius: '50%', 
                    background: darkMode ? '#2d6a4f' : '#f0fdf4',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '20px'
                  }}>
                    👤
                  </div>
                  <div>
                    <div style={{ fontWeight: '600', color: darkMode ? '#52b788' : '#2d6a4f', marginBottom: '2px' }}>
                      {testimonial.name}
                    </div>
                    <div style={{ fontSize: '14px', color: darkMode ? '#e5e7eb' : '#666' }}>
                      {testimonial.role}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{ 
        background: 'linear-gradient(135deg, #2d6a4f 0%, #52b788 100%)',
        padding: '80px 30px',
        color: 'white',
        textAlign: 'center'
      }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h2 style={{ fontSize: '42px', fontWeight: '700', marginBottom: '20px' }}>
            Ready to Taste the Difference?
          </h2>
          <p style={{ fontSize: '20px', marginBottom: '40px', opacity: 0.95 }}>
            Join our community today and enjoy the freshest local produce delivered right to your door
          </p>
          
          <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link 
              to="/products"
              style={{
                backgroundColor: 'white',
                color: '#2d6a4f',
                padding: '16px 32px',
                borderRadius: '12px',
                fontSize: '18px',
                fontWeight: '600',
                textDecoration: 'none',
                display: 'inline-block',
                transition: 'transform 0.3s ease',
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)'
              }}
              onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              Start Shopping
            </Link>
            <Link 
              to="/loyalty"
              style={{
                backgroundColor: 'transparent',
                color: 'white',
                border: '2px solid white',
                padding: '16px 32px',
                borderRadius: '12px',
                fontSize: '18px',
                fontWeight: '600',
                textDecoration: 'none',
                display: 'inline-block',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.backgroundColor = 'white';
                e.currentTarget.style.color = '#2d6a4f';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.color = 'white';
              }}
            >
              Join Loyalty Program
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
