import React, { useEffect, useRef, useContext } from 'react';
import L from 'leaflet';
import { ThemeContext } from '../context/ThemeContext';

const About = () => {
  const mapRef = useRef(null);
  const { darkMode } = useContext(ThemeContext);

  useEffect(() => {
    // Initialize Leaflet map with delay to ensure DOM is ready
    const initializeMap = () => {
      if (typeof window !== 'undefined' && !mapRef.current && document.getElementById('map')) {
        try {
          // Create map centered on Greenfield area
          const map = L.map('map').setView([52.105, -2.295], 13);

          // Add OpenStreetMap tiles
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: ' OpenStreetMap contributors'
          }).addTo(map);

          // Define producer locations with custom icons
          const producers = [
            {
              name: "Thompson's Organic Farm",
              location: "Greenfield Valley",
              lat: 52.1,
              lng: -2.3,
              products: "Organic vegetables, salad leaves, honey"
            },
            {
              name: "Davies Artisan Bakery",
              location: "Main Street, Greenfield",
              lat: 52.11,
              lng: -2.29,
              products: "Sourdough bread, rye bread, artisan loaves"
            },
            {
              name: "Greenfield Dairy Co.",
              location: "Mill Lane",
              lat: 52.105,
              lng: -2.31,
              products: "Raw milk cheese, artisan butter"
            },
            {
              name: "Happy Hens Farm",
              location: "Meadow Road",
              lat: 52.115,
              lng: -2.28,
              products: "Free range eggs, duck eggs"
            }
          ];

          // Create custom green icon for markers
          const greenIcon = L.divIcon({
            html: '<div style="background-color: #2d6a4f; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">🌱</div>',
            iconSize: [30, 30],
            className: 'custom-marker'
          });

          // Add markers for each producer
          producers.forEach(producer => {
            const marker = L.marker([producer.lat, producer.lng], { icon: greenIcon })
              .addTo(map)
              .bindPopup(`
                <div style="font-family: Arial, sans-serif;">
                  <h4 style="margin: 0 0 8px 0; color: #2d6a4f; font-size: 16px;">${producer.name}</h4>
                  <p style="margin: 0 0 8px 0; color: #666; font-size: 14px;">📍 ${producer.location}</p>
                  <p style="margin: 0; color: #52b788; font-size: 13px; font-weight: 600;">🥬 ${producer.products}</p>
                </div>
              `);
            
            // Open popup on hover
            marker.on('mouseover', function() {
              this.openPopup();
            });
          });

          mapRef.current = map;
          console.log('Map initialized successfully');
        } catch (error) {
          console.error('Error initializing map:', error);
        }
      }
    };

    // Initialize map immediately or with a small delay
    if (document.getElementById('map')) {
      initializeMap();
    } else {
      setTimeout(initializeMap, 100);
    }

    // Cleanup
    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [darkMode]); // Add darkMode dependency to reinitialize if needed

  const Card = ({ children, style = {} }) => (
    <div style={{
      backgroundColor: darkMode ? '#2d2d2d' : 'white',
      borderRadius: '16px',
      padding: '30px',
      boxShadow: darkMode ? '0 4px 20px rgba(0,0,0,0.3)' : '0 4px 20px rgba(0,0,0,0.08)',
      border: darkMode ? '1px solid #404040' : '1px solid #e8f5e9',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      ...style
    }}>
      {children}
    </div>
  );

  const StatCard = ({ number, label, darkBackground = false }) => (
    <div style={{ textAlign: 'center' }}>
      <div style={{
        fontSize: '48px',
        fontWeight: '700',
        color: darkBackground ? 'white' : '#2d6a4f',
        marginBottom: '12px',
        lineHeight: '1'
      }}>
        {number}
      </div>
      <div style={{
        fontSize: '18px',
        color: darkBackground ? '#f0fdf4' : '#212529',
        fontWeight: '600',
        marginTop: '4px'
      }}>
        {label}
      </div>
    </div>
  );

  return (
    <div style={{ backgroundColor: darkMode ? '#1a1a1a' : '#f8fafb' }}>
      {/* SECTION 1 - Hero/Mission Statement */}
      <section style={{
        background: 'linear-gradient(135deg, #2d6a4f 0%, #52b788 100%)',
        padding: '100px 30px',
        color: 'white',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{ maxWidth: '800px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <h1 style={{
            fontSize: '56px',
            fontWeight: '800',
            marginBottom: '24px',
            lineHeight: '1.1'
          }}>
            About Greenfield Local Hub
          </h1>
          <p style={{
            fontSize: '22px',
            marginBottom: '40px',
            opacity: 0.95,
            lineHeight: '1.6',
            maxWidth: '600px',
            margin: '0 auto 40px'
          }}>
            We are a cooperative of local farmers and food producers committed to bringing fresh, sustainable, and traceable food to our community.
          </p>
          <div style={{
            backgroundColor: 'rgba(255,255,255,0.15)',
            backdropFilter: 'blur(10px)',
            padding: '30px',
            borderRadius: '16px',
            border: '1px solid rgba(255,255,255,0.2)',
            maxWidth: '600px',
            margin: '0 auto'
          }}>
            <h3 style={{
              fontSize: '24px',
              fontWeight: '600',
              marginBottom: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px'
            }}>
              <span style={{ fontSize: '32px' }}>🌱</span>
              Our Mission
            </h3>
            <p style={{
              fontSize: '18px',
              lineHeight: '1.6',
              margin: 0,
              fontWeight: '500'
            }}>
              To strengthen connections between local food producers and our community
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 2 - Why Buy Local? */}
      <section style={{ padding: '80px 30px', backgroundColor: darkMode ? '#2d2d2d' : 'white' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{
              fontSize: '42px',
              color: darkMode ? '#52b788' : '#2d6a4f',
              marginBottom: '16px',
              fontWeight: '700'
            }}>
              Why Buy Local?
            </h2>
            <p style={{
              fontSize: '18px',
              color: darkMode ? '#e5e7eb' : '#666',
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              Discover the benefits of supporting your local food system
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '30px'
          }}>
            <Card style={{
              textAlign: 'center',
              cursor: 'pointer'
            }}>
              <div style={{
                fontSize: '64px',
                marginBottom: '20px',
                lineHeight: '1'
              }}>
                💰
              </div>
              <h3 style={{
                fontSize: '24px',
                color: darkMode ? '#52b788' : '#2d6a4f',
                marginBottom: '16px',
                fontWeight: '700'
              }}>
                Support Local Economy
              </h3>
              <p style={{
                color: darkMode ? '#e5e7eb' : '#666',
                fontSize: '16px',
                lineHeight: '1.6'
              }}>
                Money stays in the community, creating jobs and supporting local families. Every purchase strengthens our local economy.
              </p>
            </Card>

            <Card style={{
              textAlign: 'center',
              cursor: 'pointer'
            }}>
              <div style={{
                fontSize: '64px',
                marginBottom: '20px',
                lineHeight: '1'
              }}>
                🌍
              </div>
              <h3 style={{
                fontSize: '24px',
                color: darkMode ? '#52b788' : '#2d6a4f',
                marginBottom: '16px',
                fontWeight: '700'
              }}>
                Environmental Benefits
              </h3>
              <p style={{
                color: darkMode ? '#e5e7eb' : '#666',
                fontSize: '16px',
                lineHeight: '1.6'
              }}>
                Reduced food miles and lower carbon emissions. Local food means less transportation and fresher, more sustainable choices.
              </p>
            </Card>

            <Card style={{
              textAlign: 'center',
              cursor: 'pointer'
            }}>
              <div style={{
                fontSize: '64px',
                marginBottom: '20px',
                lineHeight: '1'
              }}>
                🥕
              </div>
              <h3 style={{
                fontSize: '24px',
                color: darkMode ? '#52b788' : '#2d6a4f',
                marginBottom: '16px',
                fontWeight: '700'
              }}>
                Freshness & Quality
              </h3>
              <p style={{
                color: darkMode ? '#e5e7eb' : '#666',
                fontSize: '16px',
                lineHeight: '1.6'
              }}>
                Picked at peak ripeness with more nutrients and better flavor. Local produce is fresher and tastes better.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* SECTION 3 - How We Work */}
      <section style={{
        backgroundColor: darkMode ? '#2d2d2d' : '#f0fdf4',
        padding: '80px 30px'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{
              fontSize: '42px',
              color: darkMode ? '#52b788' : '#2d6a4f',
              marginBottom: '16px',
              fontWeight: '700'
            }}>
              How We Work
            </h2>
            <p style={{
              fontSize: '18px',
              color: darkMode ? '#e5e7eb' : '#666',
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              Our simple process connects producers directly with customers
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '30px'
          }}>
            {[
              { step: '1', title: 'Producers Join', desc: 'Register and verify credentials', icon: '🤝' },
              { step: '2', title: 'Customers Browse', desc: 'Discover and order products', icon: '🛒' },
              { step: '3', title: 'We Coordinate', desc: 'Manage orders and stock levels', icon: '📋' },
              { step: '4', title: 'Everyone Benefits', desc: 'Fresh food, strong local economy', icon: '🌟' }
            ].map((item, index) => (
              <div key={index} style={{ textAlign: 'center' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  backgroundColor: darkMode ? '#52b788' : '#2d6a4f',
                  color: 'white',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px',
                  fontWeight: '700',
                  margin: '0 auto 20px'
                }}>
                  {item.step}
                </div>
                <div style={{
                  fontSize: '48px',
                  marginBottom: '16px',
                  lineHeight: '1'
                }}>
                  {item.icon}
                </div>
                <h3 style={{
                  fontSize: '20px',
                  color: darkMode ? '#52b788' : '#2d6a4f',
                  marginBottom: '12px',
                  fontWeight: '700'
                }}>
                  {item.title}
                </h3>
                <p style={{
                  color: darkMode ? '#e5e7eb' : '#666',
                  fontSize: '15px',
                  lineHeight: '1.5'
                }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4 - Our Commitments */}
      <section style={{ padding: '80px 30px', backgroundColor: darkMode ? '#2d2d2d' : 'white' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{
              fontSize: '42px',
              color: darkMode ? '#52b788' : '#2d6a4f',
              marginBottom: '16px',
              fontWeight: '700'
            }}>
              Our Commitments
            </h2>
            <p style={{
              fontSize: '18px',
              color: darkMode ? '#e5e7eb' : '#666',
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              The values that guide everything we do
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '30px'
          }}>
            {[
              { title: 'Full Transparency', desc: 'Complete traceability from farm to table', icon: '🔍' },
              { title: 'Fair Prices', desc: 'Fair compensation for producers, good value for customers', icon: '⚖️' },
              { title: 'Quality Standards', desc: 'Rigorous quality checks and sustainable practices', icon: '✨' },
              { title: 'Accessibility', desc: 'Fresh, local food accessible to everyone', icon: '🌍' }
            ].map((item, index) => (
              <Card key={index} style={{ textAlign: 'center' }}>
                <div style={{
                  fontSize: '48px',
                  marginBottom: '20px',
                  lineHeight: '1'
                }}>
                  {item.icon}
                </div>
                <h3 style={{
                  fontSize: '22px',
                  color: darkMode ? '#52b788' : '#2d6a4f',
                  marginBottom: '16px',
                  fontWeight: '700'
                }}>
                  {item.title}
                </h3>
                <p style={{
                  color: darkMode ? '#e5e7eb' : '#666',
                  fontSize: '16px',
                  lineHeight: '1.6'
                }}>
                  {item.desc}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 5 - Our Impact */}
      <section style={{
        backgroundColor: darkMode ? '#2d6a4f' : '#2d6a4f',
        padding: '80px 30px',
        color: 'white'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{
              fontSize: '42px',
              marginBottom: '16px',
              fontWeight: '700'
            }}>
              Our Impact
            </h2>
            <p style={{
              fontSize: '18px',
              opacity: 0.9,
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              Making a real difference in our community
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '40px'
          }}>
            <StatCard number="25+" label="Local Producers" darkBackground={true} />
            <StatCard number="2000+" label="Active Customers" darkBackground={true} />
            <StatCard number="50,000+" label="Orders Fulfilled" darkBackground={true} />
            <StatCard number="£250k" label="Revenue to Local Producers" darkBackground={true} />
          </div>
        </div>
      </section>

      {/* SECTION 6 - MAP API */}
      <section style={{ padding: '80px 30px', backgroundColor: darkMode ? '#2d2d2d' : 'white' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '60px' }}>
            <h2 style={{
              fontSize: '42px',
              color: darkMode ? '#52b788' : '#2d6a4f',
              marginBottom: '16px',
              fontWeight: '700'
            }}>
              Our Producer Locations
            </h2>
            <p style={{
              fontSize: '18px',
              color: darkMode ? '#e5e7eb' : '#666',
              maxWidth: '600px',
              margin: '0 auto'
            }}>
              Find our local producers and see where your fresh food comes from
            </p>
          </div>

          <Card>
            <div
              id="map"
              style={{
                height: '500px',
                width: '100%',
                borderRadius: '12px',
                overflow: 'hidden',
                position: 'relative',
                zIndex: 1,
                backgroundColor: darkMode ? '#2d2d2d' : '#f0f0f0'
              }}
            />
            <div style={{
              marginTop: '20px',
              padding: '20px',
              backgroundColor: darkMode ? '#2d6a4f' : '#f0fdf4',
              borderRadius: '8px',
              border: darkMode ? '1px solid #404040' : '1px solid #e8f5e9'
            }}>
              <p style={{
                margin: 0,
                color: darkMode ? '#f0fdf4' : '#2d6a4f',
                fontSize: '14px',
                textAlign: 'center'
              }}>
                🗺️ <strong>Interactive Map:</strong> Click on markers to see producer details. Zoom and pan to explore the Greenfield area.
              </p>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default About;