import { useState, useEffect } from 'react';
import axios from 'axios';

const Loyalty = () => {
  const [user, setUser] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReward, setSelectedReward] = useState(null);

  // Mock user ID - in real app this would come from authentication
  const userId = 1;

  useEffect(() => {
    // Fetch user data and orders
    Promise.all([
      axios.get(`http://localhost:5001/api/users/${userId}`),
      axios.get(`http://localhost:5001/api/orders/${userId}`)
    ])
    .then(([userRes, ordersRes]) => {
      setUser(userRes.data);
      setOrders(ordersRes.data);
      setLoading(false);
    })
    .catch(err => {
      console.error('Error fetching loyalty data:', err);
      setLoading(false);
    });
  }, [userId]);

  const getRewards = () => [
    { 
      id: 1, 
      points: 100, 
      reward: '£5 off your next order', 
      description: 'Apply £5 discount at checkout',
      color: '#2d6a4f',
      icon: '🎁'
    },
    { 
      id: 2, 
      points: 250, 
      reward: 'Free delivery on any order', 
      description: 'No delivery charges on your next order',
      color: '#40916c',
      icon: '🚚'
    },
    { 
      id: 3, 
      points: 500, 
      reward: '15% off your whole order', 
      description: 'Get 15% discount on entire basket',
      color: '#52b788',
      icon: '💎'
    },
    { 
      id: 4, 
      points: 750, 
      reward: 'Exclusive producer hamper', 
      description: 'Curated box of premium local produce',
      color: '#74c69d',
      icon: '🧺'
    }
  ];

  const getPointsEarned = (order) => {
    return Math.floor(order.total * 10);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric'
    });
  };

  const getNextReward = () => {
    const rewards = getRewards();
    const currentPoints = user?.points || 0;
    return rewards.find(reward => reward.points > currentPoints) || rewards[rewards.length - 1];
  };

  const getProgressToNextReward = () => {
    const nextReward = getNextReward();
    const currentPoints = user?.points || 0;
    const pointsNeeded = Math.max(0, nextReward.points - currentPoints);
    const progress = currentPoints / nextReward.points;
    return { pointsNeeded, progress, nextReward };
  };

  const handleRedeemReward = (reward) => {
    if ((user?.points || 0) >= reward.points) {
      setSelectedReward(reward);
      // In a real app, this would open a confirmation modal and process the redemption
      alert(`You've redeemed: ${reward.reward}! This will be applied at your next checkout.`);
    }
  };

  if (loading) {
    return (
      <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <p style={{ color: '#666', fontSize: '18px' }}>Loading loyalty program...</p>
        </div>
      </div>
    );
  }

  const currentPoints = user?.points || 0;
  const { pointsNeeded, progress, nextReward } = getProgressToNextReward();

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '50px' }}>
        <h1 style={{ fontSize: '48px', color: '#2d6a4f', marginBottom: '15px', fontWeight: '700', textAlign: 'center' }}>
          Loyalty Rewards
        </h1>
        <p style={{ textAlign: 'center', color: '#52b788', fontSize: '20px', maxWidth: '700px', margin: '0 auto' }}>
          Earn points with every purchase and unlock exclusive rewards from our local producers
        </p>
      </div>

      {/* Current Points Card */}
      <div style={{ 
        background: 'linear-gradient(135deg, #2d6a4f 0%, #52b788 100%)', 
        padding: '40px', 
        borderRadius: '20px', 
        color: 'white',
        marginBottom: '50px',
        boxShadow: '0 8px 30px rgba(45, 106, 79, 0.3)',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{ position: 'absolute', top: '20px', right: '20px', fontSize: '80px', opacity: 0.1 }}>
          ⭐
        </div>
        
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ marginBottom: '20px' }}>
            <h2 style={{ fontSize: '24px', marginBottom: '10px', fontWeight: '600' }}>Your Points Balance</h2>
            <div style={{ fontSize: '64px', fontWeight: '700', lineHeight: '1' }}>
              {currentPoints.toLocaleString()}
            </div>
            <div style={{ fontSize: '18px', opacity: 0.9, marginTop: '5px' }}>
              points
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '20px' }}>
            <div style={{ background: 'rgba(255,255,255,0.1)', padding: '15px', borderRadius: '12px' }}>
              <div style={{ fontSize: '14px', opacity: 0.9, marginBottom: '5px' }}>Points per £1</div>
              <div style={{ fontSize: '24px', fontWeight: '700' }}>10</div>
            </div>
            <div style={{ background: 'rgba(255,255,255,0.1)', padding: '15px', borderRadius: '12px' }}>
              <div style={{ fontSize: '14px', opacity: 0.9, marginBottom: '5px' }}>Total Orders</div>
              <div style={{ fontSize: '24px', fontWeight: '700' }}>{orders.length}</div>
            </div>
            <div style={{ background: 'rgba(255,255,255,0.1)', padding: '15px', borderRadius: '12px' }}>
              <div style={{ fontSize: '14px', opacity: 0.9, marginBottom: '5px' }}>Lifetime Points</div>
              <div style={{ fontSize: '24px', fontWeight: '700' }}>
                {orders.reduce((sum, order) => sum + getPointsEarned(order), 0).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress to Next Reward */}
      <div style={{ 
        background: 'white', 
        padding: '30px', 
        borderRadius: '16px', 
        marginBottom: '50px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
        border: '1px solid #e8f5e9'
      }}>
        <h3 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '20px', fontWeight: '600' }}>
          Progress to Next Reward
        </h3>
        
        <div style={{ marginBottom: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <div>
              <div style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f' }}>
                {nextReward.icon} {nextReward.reward}
              </div>
              <div style={{ color: '#666', fontSize: '14px' }}>
                {nextReward.description}
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '24px', fontWeight: '700', color: '#52b788' }}>
                {pointsNeeded}
              </div>
              <div style={{ color: '#666', fontSize: '14px' }}>
                points to go
              </div>
            </div>
          </div>
          
          <div style={{ 
            height: '12px', 
            background: '#e8f5e9', 
            borderRadius: '6px', 
            overflow: 'hidden',
            marginBottom: '10px'
          }}>
            <div style={{ 
              height: '100%', 
              background: 'linear-gradient(90deg, #2d6a4f, #52b788)', 
              borderRadius: '6px',
              width: `${Math.min(progress * 100, 100)}%`,
              transition: 'width 0.3s ease'
            }}></div>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', color: '#666' }}>
            <span>{currentPoints} points</span>
            <span>{nextReward.points} points</span>
          </div>
        </div>
      </div>

      {/* Available Rewards */}
      <div style={{ marginBottom: '50px' }}>
        <h2 style={{ color: '#2d6a4f', fontSize: '32px', marginBottom: '30px', fontWeight: '600', textAlign: 'center' }}>
          Available Rewards
        </h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '25px' }}>
          {getRewards().map((reward) => {
            const canRedeem = currentPoints >= reward.points;
            const isCurrentReward = selectedReward?.id === reward.id;
            
            return (
              <div 
                key={reward.id}
                style={{ 
                  background: 'white', 
                  padding: '30px', 
                  borderRadius: '16px', 
                  border: `2px solid ${canRedeem ? reward.color : '#e8f5e9'}`,
                  textAlign: 'center',
                  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                  cursor: canRedeem ? 'pointer' : 'default',
                  opacity: canRedeem ? 1 : 0.7,
                  position: 'relative'
                }}
                onMouseOver={(e) => {
                  if (canRedeem) {
                    e.currentTarget.style.transform = 'translateY(-5px)';
                    e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.15)';
                  }
                }}
                onMouseOut={(e) => {
                  if (canRedeem) {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
                onClick={() => canRedeem && handleRedeemReward(reward)}
              >
                {!canRedeem && (
                  <div style={{
                    position: 'absolute',
                    top: '15px',
                    right: '15px',
                    background: '#f3f4f6',
                    color: '#9ca3af',
                    padding: '4px 8px',
                    borderRadius: '12px',
                    fontSize: '11px',
                    fontWeight: '600'
                  }}>
                    LOCKED
                  </div>
                )}
                
                <div style={{ fontSize: '48px', marginBottom: '15px' }}>
                  {reward.icon}
                </div>
                
                <div style={{ fontSize: '32px', fontWeight: '700', color: reward.color, marginBottom: '10px' }}>
                  {reward.points}
                </div>
                <div style={{ color: '#666', fontSize: '14px', marginBottom: '15px' }}>
                  points
                </div>
                
                <div style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f', marginBottom: '10px' }}>
                  {reward.reward}
                </div>
                
                <div style={{ color: '#666', fontSize: '14px', marginBottom: '20px', lineHeight: '1.4' }}>
                  {reward.description}
                </div>
                
                <button 
                  disabled={!canRedeem}
                  style={{ 
                    padding: '12px 24px',
                    background: canRedeem ? reward.color : '#e5e7eb',
                    color: canRedeem ? 'white' : '#9ca3af',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: canRedeem ? 'pointer' : 'not-allowed',
                    width: '100%',
                    transition: 'background 0.3s ease'
                  }}
                >
                  {canRedeem ? 'Redeem Now' : `${reward.points - currentPoints} points needed`}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Points Activity */}
      <div>
        <h2 style={{ color: '#2d6a4f', fontSize: '32px', marginBottom: '30px', fontWeight: '600', textAlign: 'center' }}>
          Recent Points Activity
        </h2>
        
        {orders.length === 0 ? (
          <div style={{ 
            background: 'white', 
            padding: '60px 30px', 
            borderRadius: '16px', 
            textAlign: 'center',
            border: '1px solid #e8f5e9'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '20px' }}>🛒</div>
            <h3 style={{ color: '#2d6a4f', marginBottom: '10px' }}>No orders yet</h3>
            <p style={{ color: '#666', marginBottom: '20px' }}>
              Start shopping to earn loyalty points
            </p>
            <button 
              onClick={() => window.location.href = '/products'}
              style={{ 
                background: '#2d6a4f', 
                color: 'white', 
                border: 'none', 
                padding: '12px 24px', 
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              Browse Products
            </button>
          </div>
        ) : (
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '16px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            border: '1px solid #e8f5e9'
          }}>
            <div style={{ display: 'grid', gap: '15px' }}>
              {orders.slice(0, 5).map((order, index) => (
                <div key={order.id} style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center',
                  padding: '15px',
                  background: '#f8f9fa',
                  borderRadius: '12px',
                  border: '1px solid #e8f5e9'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                    <div style={{ 
                      width: '40px', 
                      height: '40px', 
                      borderRadius: '50%', 
                      background: '#f0fdf4',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '20px'
                    }}>
                      🛒
                    </div>
                    <div>
                      <div style={{ fontWeight: '600', color: '#2d6a4f', marginBottom: '2px' }}>
                        Order #{order.id}
                      </div>
                      <div style={{ fontSize: '14px', color: '#666' }}>
                        {formatDate(order.created_at)} • £{order.total.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ 
                      fontSize: '18px', 
                      fontWeight: '700', 
                      color: '#52b788',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px'
                    }}>
                      +{getPointsEarned(order)} <span style={{ fontSize: '16px' }}>⭐</span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#666' }}>
                      points earned
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {orders.length > 5 && (
              <div style={{ textAlign: 'center', marginTop: '20px' }}>
                <button style={{ 
                  background: 'transparent', 
                  color: '#2d6a4f', 
                  border: '1px solid #2d6a4f', 
                  padding: '10px 20px', 
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}>
                  View All Orders
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* How It Works */}
      <div style={{ marginTop: '60px' }}>
        <h2 style={{ color: '#2d6a4f', fontSize: '32px', marginBottom: '30px', fontWeight: '600', textAlign: 'center' }}>
          How It Works
        </h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '30px' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%', 
              background: '#f0fdf4',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '32px',
              margin: '0 auto 20px'
            }}>
              🛍️
            </div>
            <h3 style={{ color: '#2d6a4f', marginBottom: '10px', fontSize: '20px' }}>Shop</h3>
            <p style={{ color: '#666', lineHeight: '1.6' }}>
              Browse our selection of fresh local produce and add items to your basket
            </p>
          </div>
          
          <div style={{ textAlign: 'center' }}>
            <div style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%', 
              background: '#f0fdf4',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '32px',
              margin: '0 auto 20px'
            }}>
              ⭐
            </div>
            <h3 style={{ color: '#2d6a4f', marginBottom: '10px', fontSize: '20px' }}>Earn</h3>
            <p style={{ color: '#666', lineHeight: '1.6' }}>
              Get 10 points for every £1 spent on your orders
            </p>
          </div>
          
          <div style={{ textAlign: 'center' }}>
            <div style={{ 
              width: '80px', 
              height: '80px', 
              borderRadius: '50%', 
              background: '#f0fdf4',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '32px',
              margin: '0 auto 20px'
            }}>
              🎁
            </div>
            <h3 style={{ color: '#2d6a4f', marginBottom: '10px', fontSize: '20px' }}>Redeem</h3>
            <p style={{ color: '#666', lineHeight: '1.6' }}>
              Exchange your points for exclusive rewards and discounts
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Loyalty;