import { useState, useContext, useEffect } from 'react';
import { CartContext } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const Checkout = () => {
  const { cart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [orderType, setOrderType] = useState('delivery');
  const [formData, setFormData] = useState({
    deliveryAddress: '',
    collectionTime: '10:00',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedReward, setSelectedReward] = useState(null);

  // Fetch fresh user data for points balance
  useEffect(() => {
    if (user && user.id) {
      axios.get(`http://localhost:5001/api/users/${user.id}`)
        .then(res => setCurrentUser(res.data))
        .catch(err => console.error('Error fetching user data:', err));
    }
  }, [user?.id]);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = orderType === 'delivery' ? 3.50 : 0;
  
  // Calculate discounts based on selected reward
  let discount = 0;
  let finalDeliveryFee = deliveryFee;
  
  if (selectedReward) {
    if (selectedReward.type === 'discount') {
      discount = selectedReward.value; // £5 off
    } else if (selectedReward.type === 'freeDelivery') {
      finalDeliveryFee = 0; // Free delivery
    } else if (selectedReward.type === 'percentage') {
      discount = subtotal * 0.15; // 15% off
    }
  }
  
  const total = subtotal + finalDeliveryFee - discount;
  
  const currentPoints = currentUser?.points || user?.points || 0;

  const rewards = [
    { 
      id: 1, 
      points: 100, 
      reward: '£5 off your next order', 
      type: 'discount', 
      value: 5,
      color: '#2d6a4f' 
    },
    { 
      id: 2, 
      points: 250, 
      reward: 'Free delivery on any order', 
      type: 'freeDelivery', 
      value: 0,
      color: '#40916c' 
    },
    { 
      id: 3, 
      points: 500, 
      reward: '15% off your whole order', 
      type: 'percentage', 
      value: 15,
      color: '#52b788' 
    }
  ];

  const collectionTimeSlots = [
    '10:00', '10:30', '11:00', '11:30', '12:00', '12:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
  ];

  const validateForm = () => {
    const newErrors = {};
    
    if (orderType === 'delivery' && !formData.deliveryAddress.trim()) {
      newErrors.deliveryAddress = 'Delivery address is required';
    }
    
    if (orderType === 'collection' && !formData.collectionTime) {
      newErrors.collectionTime = 'Collection time is required';
    }
    
    if (cart.length === 0) {
      newErrors.cart = 'Your basket is empty';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      // Get user ID from authentication
      if (!user || !user.id) {
        throw new Error('User not authenticated');
      }
      
      const orderData = {
        user_id: user.id,
        items: cart.map(item =>({
          product_id: item.id,
          quantity: item.quantity,
          price: item.price
        })),
        total: total,
        order_type: orderType,
        delivery_address: orderType === 'delivery' ? formData.deliveryAddress : null,
        collection_time: orderType === 'collection' ? formData.collectionTime : null,
        pointsUsed: selectedReward ? selectedReward.points : 0
      };
      
      const response = await axios.post('http://localhost:5001/api/orders', orderData);
      
      if (response.data.success) {
        clearCart();
        navigate('/account', { 
          state: { 
            orderSuccess: true, 
            orderId: response.data.orderId,
            pointsEarned: response.data.pointsEarned
          } 
        });
      }
    } catch (error) {
      console.error('Error placing order:', error);
      setErrors({ submit: 'Failed to place order. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (cart.length === 0) {
    return (
      <div style={{ maxWidth: '800px', margin: '40px auto', padding: '0 30px' }}>
        <div style={{ 
          background: 'white', 
          padding: '80px 40px', 
          borderRadius: '16px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
        }}>
          <div style={{ fontSize: '64px', marginBottom: '20px' }}>🛒</div>
          <h2 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '28px' }}>Your basket is empty</h2>
          <p style={{ color: '#666', marginBottom: '30px' }}>
            Add some items to your basket before checking out
          </p>
          <button 
            onClick={() => navigate('/products')}
            style={{ 
              background: '#2d6a4f', 
              color: 'white', 
              border: 'none', 
              padding: '15px 30px', 
              borderRadius: '8px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '42px', color: '#2d6a4f', marginBottom: '10px', fontWeight: '700' }}>Checkout</h1>
        <p style={{ color: '#52b788', fontSize: '18px' }}>
          Complete your order for fresh local produce
        </p>
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '30px' }}>
        {/* Main Checkout Form */}
        <div>
          {/* Order Type Selection */}
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '16px', 
            marginBottom: '30px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            border: '1px solid #e8f5e9'
          }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
              Delivery Method
            </h2>
            
            <div style={{ display: 'grid', gap: '15px' }}>
              <label style={{ 
                display: 'flex', 
                alignItems: 'center', 
                padding: '20px',
                border: `2px solid ${orderType === 'delivery' ? '#2d6a4f' : '#e8f5e9'}`,
                borderRadius: '12px',
                cursor: 'pointer',
                background: orderType === 'delivery' ? '#f0fdf4' : 'white',
                transition: 'all 0.3s ease'
              }}>
                <input 
                  type="radio"
                  name="orderType"
                  value="delivery"
                  checked={orderType === 'delivery'}
                  onChange={(e) => setOrderType(e.target.value)}
                  style={{ marginRight: '15px', width: '20px', height: '20px' }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f', marginBottom: '5px' }}>
                    🚚 Home Delivery
                  </div>
                  <div style={{ color: '#666', fontSize: '14px' }}>
                    Get your order delivered to your doorstep (+£3.50)
                  </div>
                </div>
              </label>

              <label style={{ 
                display: 'flex', 
                alignItems: 'center', 
                padding: '20px',
                border: `2px solid ${orderType === 'collection' ? '#2d6a4f' : '#e8f5e9'}`,
                borderRadius: '12px',
                cursor: 'pointer',
                background: orderType === 'collection' ? '#f0fdf4' : 'white',
                transition: 'all 0.3s ease'
              }}>
                <input 
                  type="radio"
                  name="orderType"
                  value="collection"
                  checked={orderType === 'collection'}
                  onChange={(e) => setOrderType(e.target.value)}
                  style={{ marginRight: '15px', width: '20px', height: '20px' }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f', marginBottom: '5px' }}>
                    🏪 Click & Collect
                  </div>
                  <div style={{ color: '#666', fontSize: '14px' }}>
                    Collect your order from our hub (Free)
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Delivery Address */}
          {orderType === 'delivery' && (
            <div style={{ 
              background: 'white', 
              padding: '30px', 
              borderRadius: '16px', 
              marginBottom: '30px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
              border: '1px solid #e8f5e9'
            }}>
              <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
                Delivery Address
              </h2>
              
              <div>
                <label style={{ display: 'block', marginBottom: '8px', color: '#333', fontWeight: '500' }}>
                  Street Address *
                </label>
                <input
                  type="text"
                  value={formData.deliveryAddress}
                  onChange={(e) => handleInputChange('deliveryAddress', e.target.value)}
                  placeholder="Enter your full address"
                  style={{ 
                    width: '100%', 
                    padding: '12px', 
                    border: errors.deliveryAddress ? '2px solid #dc2626' : '1px solid #ddd', 
                    borderRadius: '8px',
                    fontSize: '16px'
                  }}
                />
                {errors.deliveryAddress && (
                  <p style={{ color: '#dc2626', fontSize: '14px', marginTop: '5px' }}>
                    {errors.deliveryAddress}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Collection Time */}
          {orderType === 'collection' && (
            <div style={{ 
              background: 'white', 
              padding: '30px', 
              borderRadius: '16px', 
              marginBottom: '30px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
              border: '1px solid #e8f5e9'
            }}>
              <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
                Collection Time
              </h2>
              
              <div>
                <label style={{ display: 'block', marginBottom: '8px', color: '#333', fontWeight: '500' }}>
                  Select a time slot *
                </label>
                <select
                  value={formData.collectionTime}
                  onChange={(e) => handleInputChange('collectionTime', e.target.value)}
                  style={{ 
                    width: '100%', 
                    padding: '12px', 
                    border: errors.collectionTime ? '2px solid #dc2626' : '1px solid #ddd', 
                    borderRadius: '8px',
                    fontSize: '16px'
                  }}
                >
                  <option value="">Select a time</option>
                  {collectionTimeSlots.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
                {errors.collectionTime && (
                  <p style={{ color: '#dc2626', fontSize: '14px', marginTop: '5px' }}>
                    {errors.collectionTime}
                  </p>
                )}
              </div>
              
              <div style={{ 
                background: '#f0fdf4', 
                padding: '15px', 
                borderRadius: '8px', 
                marginTop: '20px' 
              }}>
                <p style={{ color: '#2d6a4f', margin: 0, fontSize: '14px' }}>
                  <strong>Collection Location:</strong> Greenfield Local Hub, Market Square, Greenfield
                </p>
              </div>
            </div>
          )}

          {/* Points Redemption */}
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '16px', 
            marginBottom: '30px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            border: '1px solid #e8f5e9'
          }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
              Loyalty Points Redemption
            </h2>
            
            <div style={{ 
              background: '#f0fdf4', 
              padding: '15px', 
              borderRadius: '8px', 
              marginBottom: '20px' 
            }}>
              <p style={{ color: '#2d6a4f', margin: 0, fontSize: '16px', fontWeight: '500' }}>
                🌱 You have <strong>{currentPoints}</strong> loyalty points available
              </p>
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', color: '#333', fontWeight: '500' }}>
                Select a reward to redeem:
              </label>
              <select
                value={selectedReward?.id || ''}
                onChange={(e) => {
                  const reward = rewards.find(r => r.id === parseInt(e.target.value));
                  setSelectedReward(reward || null);
                }}
                style={{ 
                  width: '100%', 
                  padding: '12px', 
                  border: '1px solid #ddd', 
                  borderRadius: '8px',
                  fontSize: '16px'
                }}
              >
                <option value="">No reward selected</option>
                {rewards.map(reward => (
                  <option 
                    key={reward.id} 
                    value={reward.id}
                    disabled={currentPoints < reward.points}
                  >
                    {reward.reward} ({reward.points} points)
                    {currentPoints < reward.points && ` - ${reward.points - currentPoints} points needed`}
                  </option>
                ))}
              </select>
            </div>
            
            {selectedReward && (
              <div style={{ 
                background: '#e8f5e9', 
                padding: '15px', 
                borderRadius: '8px',
                marginBottom: '15px'
              }}>
                <p style={{ color: '#2d6a4f', margin: 0, fontSize: '14px' }}>
                  <strong>Reward Applied:</strong> {selectedReward.reward}<br/>
                  <strong>Points Used:</strong> {selectedReward.points} points<br/>
                  <strong>You Save:</strong> {selectedReward.type === 'discount' ? `£${selectedReward.value}` : 
                                   selectedReward.type === 'freeDelivery' ? 'Free delivery' :
                                   '15% off your order'}
                </p>
              </div>
            )}
          </div>

          {/* Order Notes */}
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '16px', 
            marginBottom: '30px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            border: '1px solid #e8f5e9'
          }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
              Order Notes (Optional)
            </h2>
            
            <textarea
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Any special instructions for your order..."
              rows="4"
              style={{ 
                width: '100%', 
                padding: '12px', 
                border: '1px solid #ddd', 
                borderRadius: '8px',
                fontSize: '16px',
                resize: 'vertical'
              }}
            />
          </div>

          {/* Error Message */}
          {errors.submit && (
            <div style={{ 
              background: '#fef2f2', 
              color: '#dc2626', 
              padding: '15px', 
              borderRadius: '8px', 
              marginBottom: '20px',
              border: '1px solid #fecaca'
            }}>
              {errors.submit}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            style={{ 
              width: '100%', 
              padding: '18px', 
              background: loading ? '#9ca3af' : '#2d6a4f', 
              color: 'white', 
              border: 'none', 
              borderRadius: '12px', 
              fontSize: '18px',
              fontWeight: '600',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'background 0.3s ease'
            }}
          >
            {loading ? 'Placing Order...' : `Place Order • £${total.toFixed(2)}`}
          </button>
        </div>

        {/* Order Summary */}
        <div style={{ height: 'fit-content' }}>
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '16px', 
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            border: '1px solid #e8f5e9',
            position: 'sticky',
            top: '20px'
          }}>
            <h2 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '25px', fontWeight: '600' }}>
              Order Summary
            </h2>

            {/* Order Items */}
            <div style={{ marginBottom: '25px' }}>
              {cart.map(item => (
                <div key={item.id} style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center',
                  padding: '10px 0',
                  borderBottom: '1px solid #f3f4f6'
                }}>
                  <div>
                    <div style={{ fontWeight: '500', color: '#333' }}>{item.name}</div>
                    <div style={{ fontSize: '14px', color: '#666' }}>
                      {item.quantity} × £{item.price.toFixed(2)}
                    </div>
                  </div>
                  <div style={{ fontWeight: '600', color: '#2d6a4f' }}>
                    £{(item.price * item.quantity).toFixed(2)}
                  </div>
                </div>
              ))}
            </div>

            {/* Price Breakdown */}
            <div style={{ display: 'grid', gap: '15px', marginBottom: '25px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#666' }}>Subtotal</span>
                <span style={{ fontSize: '16px', fontWeight: '600', color: '#333' }}>
                  £{subtotal.toFixed(2)}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#666' }}>
                  {orderType === 'delivery' ? 'Delivery' : 'Collection'}
                </span>
                <span style={{ fontSize: '16px', fontWeight: '600', color: '#333' }}>
                  {finalDeliveryFee > 0 ? `£${finalDeliveryFee.toFixed(2)}` : 'Free'}
                </span>
              </div>
              {discount > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ color: '#52b788', fontWeight: '500' }}>
                    Points Discount
                  </span>
                  <span style={{ fontSize: '16px', fontWeight: '600', color: '#52b788' }}>
                    -£{discount.toFixed(2)}
                  </span>
                </div>
              )}
              <div style={{ 
                height: '1px', 
                background: '#e8f5e9', 
                margin: '10px 0' 
              }}></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '18px', fontWeight: '600', color: '#2d6a4f' }}>Total</span>
                <span style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f' }}>
                  £{total.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Loyalty Points */}
            <div style={{ background: '#f0fdf4', padding: '15px', borderRadius: '8px', marginBottom: '25px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ fontSize: '20px' }}>🌱</span>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: '600', color: '#2d6a4f', marginBottom: '2px' }}>
                    Earn {Math.floor(total * 10)} loyalty points
                  </div>
                  <div style={{ fontSize: '12px', color: '#666' }}>
                    10 points per £1 spent
                  </div>
                </div>
              </div>
            </div>

            {/* Back to Basket */}
            <button
              type="button"
              onClick={() => navigate('/basket')}
              style={{ 
                width: '100%', 
                padding: '12px', 
                background: 'transparent', 
                color: '#2d6a4f', 
                border: '1px solid #2d6a4f', 
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.background = '#2d6a4f';
                e.currentTarget.style.color = 'white';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#2d6a4f';
              }}
            >
              ← Back to Basket
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Checkout;