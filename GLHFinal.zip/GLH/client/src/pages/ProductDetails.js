import React, { useState, useEffect, useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import axios from 'axios';

const ProductDetails = () => {
  const { id } = useParams();
  const { addToCart } = useContext(CartContext);
  const [product, setProduct] = useState(null);

  useEffect(() => {
    // Fetch product by ID from API
    const fetchProduct = async () => {
      try {
        const response = await axios.get(`http://localhost:5001/api/products`);
        const products = response.data;
        const foundProduct = products.find(p => p.id === parseInt(id));
        setProduct(foundProduct);
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    };
    fetchProduct();
  }, [id]);

  if (!product) {
    return (
      <div style={{ textAlign: 'center', padding: '100px' }}>
        <h2>Product not found</h2>
        <Link to="/products" style={{ color: '#166534' }}>← Back to Products</Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '40px 20px' }}>
      
      {/* Back Button */}
      <Link 
        to="/products" 
        style={{ 
          color: '#166534', 
          textDecoration: 'none', 
          fontSize: '18px', 
          display: 'inline-flex', 
          alignItems: 'center', 
          gap: '8px',
          marginBottom: '30px'
        }}
      >
        ← Back to All Products
      </Link>

      <div style={{ display: 'flex', gap: '60px', flexWrap: 'wrap' }}>
        
        {/* Image Section */}
        <div style={{ flex: '1', minWidth: '420px' }}>
          <img 
            src={product.image_url} 
            alt={product.name} 
            style={{ 
              width: '100%', 
              maxWidth: '400px',
              height: '300px',
              objectFit: 'cover',
              borderRadius: '12px', 
              boxShadow: '0 10px 30px rgba(0,0,0,0.1)' 
            }}
            onError={(e) => {
              e.target.style.display = 'none';
              const placeholder = document.createElement('div');
              placeholder.style.cssText = 'width: 100%; max-width: 400px; height: 300px; display: flex; align-items: center; justify-content: center; font-size: 72px; background: #f0fdf4; border-radius: 12px; color: #2d6a4f;';
              placeholder.textContent = product.category === 'Vegetables' ? '🥕' : product.category === 'Bakery' ? '🍞' : product.category === 'Dairy' ? '🥛' : product.category === 'Eggs' ? '🥚' : '🌿';
              e.target.parentNode.insertBefore(placeholder, e.target);
            }}
          />
        </div>

        {/* Details Section */}
        <div style={{ flex: '1', minWidth: '420px' }}>
          <h1 style={{ fontSize: '38px', marginBottom: '12px' }}>{product.name}</h1>
          
          <p style={{ color: '#555', fontSize: '18px', lineHeight: '1.6', marginBottom: '30px' }}>
            {product.description}
          </p>

          <div style={{ marginBottom: '30px' }}>
            <div style={{ fontSize: '36px', fontWeight: 'bold', color: '#166534' }}>
              £{product.price.toFixed(2)}
            </div>
            <div style={{ color: '#666', fontSize: '18px' }}>per {product.unit}</div>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <span style={{ 
              backgroundColor: '#ecfdf5', 
              color: '#166534', 
              padding: '8px 18px', 
              borderRadius: '9999px', 
              fontSize: '15px' 
            }}>
              In stock ({product.stock})
            </span>
            <div style={{ marginTop: '12px', color: '#555', fontSize: '17px' }}>
              Producer: <strong>{product.producer}</strong>
            </div>
          </div>

          {/* Action Buttons */}
          <button
            onClick={() => addToCart(product)}
            style={{
              width: '100%',
              padding: '18px',
              backgroundColor: '#166534',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer',
              marginBottom: '15px'
            }}
          >
            Add to Cart
          </button>

          <Link 
            to="/basket"
            style={{ 
              display: 'block', 
              textAlign: 'center', 
              color: '#166534', 
              fontWeight: '600',
              fontSize: '17px',
              padding: '12px',
              border: '2px solid #166534',
              borderRadius: '12px',
              textDecoration: 'none'
            }}
          >
            View Cart →
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;