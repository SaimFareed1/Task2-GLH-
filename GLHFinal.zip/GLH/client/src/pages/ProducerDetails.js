import React, { useState, useEffect, useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';

const mockProducts = [
  {
    id: 1,
    name: "Organic Mixed Salad Leaves",
    description: "Fresh seasonal salad mix including lettuce, rocket, and mizuna. Grown sustainably on local farms without pesticides.",
    price: 2.50,
    unit: "200g",
    stock: 45,
    category: "Vegetables",
    image: "https://picsum.photos/id/1015/800/600",
    producer: "Thompson's Organic Farm"
  },
  {
    id: 2,
    name: "Heritage Tomatoes",
    description: "Heirloom variety tomatoes in various colors. Sweet, juicy, and full of flavour. Perfect for salads and cooking.",
    price: 4.00,
    unit: "500g",
    stock: 30,
    category: "Vegetables",
    image: "https://picsum.photos/id/292/800/600",
    producer: "Thompson's Organic Farm"
  },
  {
    id: 3,
    name: "Sourdough Loaf",
    description: "Traditional sourdough made with heritage wheat using long fermentation methods. No artificial additives.",
    price: 3.50,
    unit: "800g",
    stock: 20,
    category: "Bakery",
    image: "https://picsum.photos/id/201/800/600",
    producer: "Davies Artisan Bakery"
  },
  // Add more products here if needed
];

const ProductDetails = () => {
  const { id } = useParams();
  const { addToCart } = useContext(CartContext);
  const [product, setProduct] = useState(null);

  useEffect(() => {
    const foundProduct = mockProducts.find(p => p.id === parseInt(id));
    setProduct(foundProduct);
  }, [id]);

  if (!product) {
    return <div style={{ textAlign: 'center', padding: '100px' }}>Product not found</div>;
  }

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <Link to="/products" style={{ color: '#166534', textDecoration: 'none', marginBottom: '20px', display: 'inline-block' }}>
        ← Back to Products
      </Link>

      <div style={{ display: 'flex', gap: '60px', flexWrap: 'wrap' }}>
        {/* Image */}
        <div style={{ flex: '1', minWidth: '400px' }}>
          <img 
            src={product.image} 
            alt={product.name} 
            style={{ width: '100%', borderRadius: '16px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }}
          />
        </div>

        {/* Details */}
        <div style={{ flex: '1', minWidth: '400px' }}>
          <h1 style={{ fontSize: '36px', marginBottom: '10px' }}>{product.name}</h1>
          <p style={{ color: '#555', fontSize: '18px', marginBottom: '20px' }}>{product.description}</p>

          <div style={{ marginBottom: '30px' }}>
            <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#166534' }}>
              £{product.price.toFixed(2)}
            </div>
            <div style={{ color: '#666' }}>per {product.unit}</div>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <span style={{ backgroundColor: '#ecfdf5', color: '#166534', padding: '8px 16px', borderRadius: '9999px', fontSize: '15px' }}>
              In stock ({product.stock})
            </span>
            <div style={{ marginTop: '10px', color: '#555' }}>
              Producer: <strong>{product.producer}</strong>
            </div>
          </div>

          <button
            onClick={() => addToCart(product)}
            style={{
              width: '100%',
              padding: '16px',
              backgroundColor: '#166534',
              color: 'white',
              border: 'none',
              borderRadius: '10px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer',
              marginBottom: '15px'
            }}
          >
            Add to Cart
          </button>

          <Link to="/basket" style={{
            display: 'block',
            textAlign: 'center',
            color: '#166534',
            fontWeight: '500'
          }}>
            View Cart
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails; 