import React, { useState, useContext, useEffect } from 'react';
import { CartContext } from '../context/CartContext';
import { ProductContext } from '../context/ProductContext';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Products = () => {
  const { products: contextProducts } = useContext(ProductContext);
  const { addToCart } = useContext(CartContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('name');

  const categories = ['All', 'Vegetables', 'Bakery', 'Dairy', 'Eggs', 'Pantry'];

  useEffect(() => {
    // Fetch products from API to get real-time stock data
    setLoading(true);
    
    axios.get('http://localhost:5001/api/products')
      .then(res => {
        console.log('Products fetched from API:', res.data.length);
        setProducts(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching products:', err);
        // Fallback to hardcoded products if API fails
        const fallbackProducts = [
          { id: 1, name: 'Organic Mixed Salad Leaves', price: 4.00, description: 'Fresh organic salad mix including lettuce, rocket, and mizuna', image_url: 'https://picsum.photos/id/1015/400/300', stock: 30, category: 'Vegetables', unit: '500g', availability: 'in_stock' },
          { id: 2, name: 'Heritage Tomatoes', price: 3.50, description: 'Heirloom variety tomatoes in various colors, vine-ripened', image_url: 'https://picsum.photos/id/292/400/300', stock: 20, category: 'Vegetables', unit: '800g', availability: 'in_stock' },
          { id: 3, name: 'Sourdough Loaf', price: 2.50, description: 'Traditional sourdough made with heritage grains, long fermentation', image_url: 'https://picsum.photos/id/201/400/300', stock: 45, category: 'Bakery', unit: '200g', availability: 'in_stock' },
          { id: 4, name: 'Free Range Eggs (6)', price: 2.80, description: 'Large brown eggs from happy hens, 6 per pack', image_url: 'https://picsum.photos/id/701/400/300', stock: 60, category: 'Eggs', unit: 'pack', availability: 'in_stock' },
          { id: 5, name: 'Raw Cow Milk Cheese', price: 5.50, description: 'Artisan cheese made from raw cow milk, aged 3 months', image_url: 'https://picsum.photos/id/401/400/300', stock: 15, category: 'Dairy', unit: '250g', availability: 'low_stock' },
          { id: 6, name: 'Artisan Butter', price: 3.20, description: 'Rich, creamy butter from grass-fed cows', image_url: 'https://picsum.photos/id/501/400/300', stock: 25, category: 'Dairy', unit: '200g', availability: 'in_stock' },
          { id: 7, name: 'Honey Jar', price: 6.00, description: 'Pure wildflower honey, raw and unfiltered', image_url: 'https://picsum.photos/id/601/400/300', stock: 12, category: 'Pantry', unit: '340g', availability: 'in_stock' },
          { id: 8, name: 'Seasonal Vegetables Box', price: 12.00, description: 'Mixed seasonal vegetables, changes weekly', image_url: 'https://picsum.photos/id/801/400/300', stock: 10, category: 'Vegetables', unit: 'box', availability: 'in_stock' },
          { id: 9, name: 'Rye Sourdough', price: 3.80, description: 'Dark rye sourdough with traditional starter', image_url: 'https://picsum.photos/id/901/400/300', stock: 18, category: 'Bakery', unit: 'loaf', availability: 'in_stock' },
          { id: 10, name: 'Duck Eggs (6)', price: 4.50, description: 'Large duck eggs with rich yolks, 6 per pack', image_url: 'https://picsum.photos/id/111/400/300', stock: 8, category: 'Eggs', unit: 'pack', availability: 'low_stock' },
          { id: 11, name: 'Apple Cider Vinegar', price: 5.50, description: 'Raw apple cider vinegar with mother', image_url: 'https://picsum.photos/id/121/400/300', stock: 20, category: 'Pantry', unit: 'bottle', availability: 'in_stock' },
          { id: 12, name: 'Organic Carrots', price: 2.00, description: 'Sweet organic carrots, perfect for roasting or juicing', image_url: 'https://picsum.photos/id/131/400/300', stock: 40, category: 'Vegetables', unit: '1kg', availability: 'in_stock' }
        ];
        setProducts(fallbackProducts);
        setLoading(false);
      });
  }, []);

  const getAvailabilityBadge = (stock, availability) => {
    if (stock === 0 || availability === 'out_of_stock') {
      return { text: 'Out of Stock', color: '#dc2626', bgColor: '#fef2f2', showStock: false };
    }
    if (stock < 5 || availability === 'low_stock') {
      return { text: 'Low Stock', color: '#f59e0b', bgColor: '#fffbeb', showStock: true, stockText: `Only ${stock} left` };
    }
    if (stock < 10) {
      return { text: 'Limited', color: '#f59e0b', bgColor: '#fffbeb', showStock: true, stockText: `${stock} available` };
    }
    return { text: 'In Stock', color: '#10b981', bgColor: '#f0fdf4', showStock: false };
  };

  const filteredAndSortedProducts = products
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            product.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'stock':
          return b.stock - a.stock;
        default:
          return 0;
      }
    });

  const handleAddToCart = (product, e) => {
    e.preventDefault();
    if (product.stock > 0) {
      addToCart(product);
    }
  };

  const refreshProducts = () => {
    setLoading(true);
    axios.get('http://localhost:5001/api/products')
      .then(res => {
        console.log('Products refreshed:', res.data.length);
        setProducts(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error refreshing products:', err);
        setLoading(false);
      });
  };

  if (loading) {
    return (
      <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <p style={{ color: '#666', fontSize: '18px' }}>Loading fresh products...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '50px' }}>
        <h1 style={{ fontSize: '48px', color: '#2d6a4f', marginBottom: '15px', fontWeight: '700', textAlign: 'center' }}>
          Fresh Local Produce
        </h1>
        <p style={{ textAlign: 'center', color: '#52b788', fontSize: '20px', maxWidth: '700px', margin: '0 auto' }}>
          Discover high-quality, locally-sourced products from our trusted producers. 
          Every purchase supports sustainable farming in our community.
        </p>
      </div>

      {/* Search and Filters */}
      <div style={{ marginBottom: '40px' }}>
        {/* Search Bar */}
        <div style={{ maxWidth: '600px', margin: '0 auto 30px' }}>
          <div style={{ position: 'relative' }}>
            <input
              type="text"
              placeholder="Search for fresh vegetables, artisan breads, dairy products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                width: '100%',
                padding: '16px 20px 16px 50px',
                borderRadius: '50px',
                border: '2px solid #e8f5e9',
                fontSize: '16px',
                outline: 'none',
                transition: 'border-color 0.3s ease'
              }}
              onFocus={(e) => e.currentTarget.style.borderColor = '#2d6a4f'}
              onBlur={(e) => e.currentTarget.style.borderColor = '#e8f5e9'}
            />
            <span style={{ 
              position: 'absolute', 
              left: '20px', 
              top: '50%', 
              transform: 'translateY(-50%)',
              fontSize: '20px',
              color: '#52b788'
            }}>
              🔍
            </span>
          </div>
        </div>

        {/* Category Filters */}
        <div style={{ marginBottom: '30px' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', justifyContent: 'center', alignItems: 'center' }}>
            <span style={{ color: '#2d6a4f', fontWeight: '600', marginRight: '10px' }}>Categories:</span>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  padding: '10px 20px',
                  borderRadius: '25px',
                  border: '2px solid',
                  borderColor: selectedCategory === cat ? '#2d6a4f' : '#e8f5e9',
                  backgroundColor: selectedCategory === cat ? '#2d6a4f' : 'white',
                  color: selectedCategory === cat ? 'white' : '#2d6a4f',
                  cursor: 'pointer',
                  fontSize: '15px',
                  fontWeight: '600',
                  transition: 'all 0.3s ease'
                }}
                onMouseOver={(e) => {
                  if (selectedCategory !== cat) {
                    e.currentTarget.style.backgroundColor = '#f0fdf4';
                  }
                }}
                onMouseOut={(e) => {
                  if (selectedCategory !== cat) {
                    e.currentTarget.style.backgroundColor = 'white';
                  }
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Sort Options */}
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '15px' }}>
          <span style={{ color: '#2d6a4f', fontWeight: '600' }}>Sort by:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              border: '2px solid #e8f5e9',
              backgroundColor: 'white',
              color: '#2d6a4f',
              fontSize: '15px',
              fontWeight: '500',
              cursor: 'pointer',
              outline: 'none'
            }}
          >
            <option value="name">Name</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="stock">Stock Level</option>
          </select>
        </div>
      </div>

      {/* Results Count and Refresh */}
      <div style={{ marginBottom: '30px', textAlign: 'center', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '15px' }}>
        <p style={{ color: '#666', fontSize: '16px', margin: 0 }}>
          Showing {filteredAndSortedProducts.length} of {products.length} products
        </p>
        <button
          onClick={refreshProducts}
          disabled={loading}
          style={{
            padding: '8px 16px',
            backgroundColor: loading ? '#e5e7eb' : '#2d6a4f',
            color: loading ? '#9ca3af' : 'white',
            border: 'none',
            borderRadius: '6px',
            fontSize: '14px',
            fontWeight: '500',
            cursor: loading ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            transition: 'background 0.3s ease'
          }}
          onMouseOver={(e) => {
            if (!loading) {
              e.currentTarget.style.backgroundColor = '#40916c';
            }
          }}
          onMouseOut={(e) => {
            if (!loading) {
              e.currentTarget.style.backgroundColor = '#2d6a4f';
            }
          }}
        >
          🔄 Refresh Stock
        </button>
      </div>

      {/* Product Grid */}
      {filteredAndSortedProducts.length === 0 ? (
        <div style={{ 
          textAlign: 'center', 
          padding: '80px 40px',
          background: 'white',
          borderRadius: '16px',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '64px', marginBottom: '20px' }}>🔍</div>
          <h3 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '24px' }}>No products found</h3>
          <p style={{ color: '#666', marginBottom: '30px', fontSize: '16px' }}>
            Try adjusting your search terms or browse different categories
          </p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('All');
            }}
            style={{
              padding: '12px 24px',
              backgroundColor: '#2d6a4f',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', 
          gap: '30px' 
        }}>
          {filteredAndSortedProducts.map(product => {
            const availability = getAvailabilityBadge(product.stock, product.availability);
            const isOutOfStock = product.stock === 0 || product.availability === 'out_of_stock';
            
            return (
              <div 
                key={product.id} 
                style={{
                  backgroundColor: 'white',
                  borderRadius: '16px',
                  overflow: 'hidden',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                  border: '1px solid #e8f5e9',
                  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                  cursor: 'pointer'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = 'translateY(-5px)';
                  e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.12)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)';
                }}
              >
                <Link to={`/product/${product.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ position: 'relative' }}>
                    <img 
                      src={product.image_url || 'https://picsum.photos/id/1015/400/250'} 
                      alt={product.name} 
                      style={{ 
                        width: '100%', 
                        height: '180px', 
                        objectFit: 'cover',
                        borderTopLeftRadius: '12px',
                        borderTopRightRadius: '12px',
                        transition: 'transform 0.3s ease'
                      }}
                      onError={(e) => {
                        e.target.style.display = 'none';
                        const placeholder = document.createElement('div');
                        placeholder.style.cssText = 'width: 100%; height: 180px; display: flex; align-items: center; justify-content: center; font-size: 48px; background: #f0fdf4; borderTopLeftRadius: 12px; borderTopRightRadius: 12px;';
                        placeholder.textContent = product.category === 'Vegetables' ? '🥕' : product.category === 'Bakery' ? '🍞' : product.category === 'Dairy' ? '🥛' : product.category === 'Eggs' ? '🥚' : '🌿';
                        e.target.parentNode.insertBefore(placeholder, e.target);
                      }}
                    />
                    {availability.text !== 'In Stock' && (
                      <div style={{
                        position: 'absolute',
                        top: '15px',
                        right: '15px',
                        background: availability.color,
                        color: 'white',
                        padding: '6px 12px',
                        borderRadius: '20px',
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'uppercase'
                      }}>
                        {availability.text}
                      </div>
                    )}
                  </div>
                  
                  <div style={{ padding: '25px' }}>
                    <div style={{ marginBottom: '15px' }}>
                      <span style={{ 
                        background: '#f0fdf4', 
                        color: '#2d6a4f', 
                        padding: '4px 10px', 
                        borderRadius: '15px',
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'uppercase'
                      }}>
                        {product.category}
                      </span>
                    </div>
                    
                    <h3 style={{ 
                      fontSize: '20px', 
                      marginBottom: '10px', 
                      fontWeight: '700',
                      color: '#2d6a4f',
                      lineHeight: '1.3'
                    }}>
                      {product.name}
                    </h3>
                    
                    <p style={{ 
                      color: '#666', 
                      fontSize: '15px', 
                      marginBottom: '20px', 
                      lineHeight: '1.5',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}>
                      {product.description}
                    </p>

                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'center',
                      marginBottom: '20px' 
                    }}>
                      <div>
                        <div style={{ 
                          fontSize: '28px', 
                          fontWeight: '700', 
                          color: '#2d6a4f',
                          lineHeight: '1'
                        }}>
                          £{product.price.toFixed(2)}
                        </div>
                        <div style={{ 
                          fontSize: '14px', 
                          color: '#666',
                          marginTop: '2px'
                        }}>
                          per {product.unit}
                        </div>
                      </div>
                      
                      <div style={{ textAlign: 'right' }}>
                        <div style={{
                          fontSize: '12px',
                          color: '#666',
                          marginBottom: '4px'
                        }}>
                          Stock:
                        </div>
                        <div style={{
                          fontSize: '16px',
                          fontWeight: '600',
                          color: availability.color
                        }}>
                          {product.stock} {product.unit}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={(e) => handleAddToCart(product, e)}
                      disabled={isOutOfStock}
                      style={{
                        width: '100%',
                        padding: '14px',
                        backgroundColor: isOutOfStock ? '#e5e7eb' : '#2d6a4f',
                        color: isOutOfStock ? '#9ca3af' : 'white',
                        border: 'none',
                        borderRadius: '10px',
                        fontWeight: '600',
                        cursor: isOutOfStock ? 'not-allowed' : 'pointer',
                        fontSize: '16px',
                        transition: 'background 0.3s ease'
                      }}
                      onMouseOver={(e) => {
                        if (!isOutOfStock) {
                          e.currentTarget.style.backgroundColor = '#40916c';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (!isOutOfStock) {
                          e.currentTarget.style.backgroundColor = '#2d6a4f';
                        }
                      }}
                    >
                      {isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                    </button>
                  </div>
                </Link>
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Stats */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
        gap: '20px', 
        marginTop: '60px' 
      }}>
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🥬</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {products.filter(p => p.category === 'Vegetables').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Fresh Vegetables</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🍞</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {products.filter(p => p.category === 'Bakery').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Artisan Breads</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🥛</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {products.filter(p => p.category === 'Dairy').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Dairy & Eggs</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🍯</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {products.filter(p => p.category === 'Pantry').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Pantry Items</div>
        </div>
      </div>
    </div>
  );
};

export default Products;