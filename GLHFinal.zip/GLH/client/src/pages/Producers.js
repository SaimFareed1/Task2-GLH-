import { useState } from 'react';

const Producers = () => {
  // Hardcoded producers data to avoid loading issues
  const [producers] = useState([
    {
      id: 1,
      farm_name: "Thompson's Organic Farm",
      full_name: "John Thompson",
      location: "Greenfield Valley",
      methods_description: "Certified organic, no pesticides, crop rotation",
      logo_url: "https://picsum.photos/id/1005/80/80",
      categories: ["Vegetables", "Herbs"]
    },
    {
      id: 2,
      farm_name: "Davies Artisan Bakery",
      full_name: "Sarah Davies",
      location: "Main Street",
      methods_description: "Heritage grains, wood-fired oven, long fermentation",
      logo_url: "https://picsum.photos/id/1018/80/80",
      categories: ["Bakery", "Breads"]
    },
    {
      id: 3,
      farm_name: "Greenfield Dairy Co.",
      full_name: "Emma Wilson",
      location: "Mill Lane",
      methods_description: "Grass-fed cows, traditional cheese making",
      logo_url: "https://picsum.photos/id/1025/80/80",
      categories: ["Dairy", "Eggs"]
    },
    {
      id: 4,
      farm_name: "Happy Hens Farm",
      full_name: "Mike Chen",
      location: "Meadow Road",
      methods_description: "Free-range, organic feed, hen welfare focus",
      logo_url: "https://picsum.photos/id/1035/80/80",
      categories: ["Eggs", "Poultry"]
    }
  ]);

  const getProductsByCategory = (producerId) => {
    const producer = producers.find(p => p.id === producerId);
    return producer ? producer.categories : ['Various'];
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 20px' }}>
      <div style={{ textAlign: 'center', marginBottom: '50px' }}>
        <h1 style={{ fontSize: '48px', color: '#2d6a4f', marginBottom: '15px', fontWeight: '700' }}>Our Local Producers</h1>
        <p style={{ fontSize: '20px', color: '#52b788', maxWidth: '600px', margin: '0 auto' }}>
          Meet the passionate farmers and artisans who bring fresh, local produce to your table
        </p>
      </div>

      {producers.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <p style={{ fontSize: '18px', color: '#666' }}>Loading producers...</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '30px', marginBottom: '60px' }}>
          {producers.map(producer => (
            <div 
              key={producer.id} 
              style={{ 
                background: 'white', 
                borderRadius: '16px', 
                padding: '30px', 
                boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                border: '1px solid #e8f5e9',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                cursor: 'pointer'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-5px)';
                e.currentTarget.style.boxShadow = '0 8px 30px rgba(0,0,0,0.12)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)';
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
                <img 
                  src={producer.logo_url || 'https://picsum.photos/id/1005/80/80'} 
                  alt={producer.farm_name}
                  style={{ 
                    width: '80px', 
                    height: '80px', 
                    borderRadius: '50%', 
                    marginRight: '20px',
                    objectFit: 'cover',
                    border: '3px solid #52b788'
                  }}
                />
                <div>
                  <h3 style={{ color: '#2d6a4f', fontSize: '24px', marginBottom: '5px', fontWeight: '600' }}>
                    {producer.farm_name}
                  </h3>
                  <p style={{ color: '#666', fontSize: '16px', margin: 0 }}>
                    {producer.full_name}
                  </p>
                </div>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
                  <span style={{ color: '#40916c', fontWeight: '600', marginRight: '8px' }}>📍</span>
                  <span style={{ color: '#333' }}>{producer.location}</span>
                </div>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ color: '#2d6a4f', fontSize: '16px', marginBottom: '8px', fontWeight: '600' }}>
                  Farming Values
                </h4>
                <p style={{ color: '#555', lineHeight: '1.6', fontSize: '15px' }}>
                  {producer.methods_description}
                </p>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ color: '#2d6a4f', fontSize: '16px', marginBottom: '8px', fontWeight: '600' }}>
                  Products
                </h4>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {getProductsByCategory(producer.id).map((category, index) => (
                    <span 
                      key={index}
                      style={{ 
                        background: '#e8f5e9', 
                        color: '#2d6a4f', 
                        padding: '6px 12px', 
                        borderRadius: '20px',
                        fontSize: '13px',
                        fontWeight: '500'
                      }}
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>

              <button 
                style={{ 
                  width: '100%', 
                  padding: '12px 20px', 
                  background: '#2d6a4f', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: '8px',
                  fontSize: '16px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'background 0.3s ease'
                }}
                onMouseOver={(e) => e.currentTarget.style.background = '#40916c'}
                onMouseOut={(e) => e.currentTarget.style.background = '#2d6a4f'}
              >
                View Products
              </button>
            </div>
          ))}
        </div>
      )}

      <div style={{ textAlign: 'center', padding: '40px', background: '#f8f9fa', borderRadius: '16px' }}>
        <h2 style={{ color: '#2d6a4f', marginBottom: '15px' }}>Support Local, Eat Fresh</h2>
        <p style={{ color: '#666', maxWidth: '600px', margin: '0 auto', lineHeight: '1.6' }}>
          By choosing to buy from our local producers, you're not just getting fresh, high-quality produce - 
          you're supporting sustainable farming practices and strengthening our local community.
        </p>
      </div>
    </div>
  );
};

export default Producers;