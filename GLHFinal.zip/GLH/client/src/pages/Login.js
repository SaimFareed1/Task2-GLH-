import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { getValidationErrors, formatErrorMessage, sanitizeInput } from '../utils/validation';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const sanitizedValue = sanitizeInput(value);
    setFormData(prev => ({ ...prev, [name]: sanitizedValue }));
    
    // Clear field error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
    if (serverError) {
      setServerError('');
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const fieldErrors = getValidationErrors({ ...formData, [name]: value }, 'login');
    setErrors(prev => ({ ...prev, ...fieldErrors }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    
    // Validate all fields
    const validationErrors = getValidationErrors(formData, 'login');
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);

    try {
      const response = await axios.post('http://localhost:5001/api/login', formData);
      
      if (response.data.token) {
        console.log('=== LOGIN DEBUGGING ===');
        console.log('Login response:', response.data);
        console.log('User data from server:', response.data.user);
        console.log('=== END LOGIN DEBUGGING ===');
        
        login(response.data.token, response.data.user);

        // Role-based redirect
        const userRole = response.data.user.role;
        
        if (userRole === 'producer') {
          navigate('/dashboard');
        } else {
          navigate('/account');   // or '/' for home
        }
      }
    } catch (err) {
      setServerError(formatErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ 
      maxWidth: '500px', 
      margin: '60px auto', 
      padding: '50px 40px', 
      backgroundColor: 'white', 
      borderRadius: '16px', 
      boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
      border: '1px solid #e8f5e9'
    }}>
      <h2 style={{ 
        textAlign: 'center', 
        marginBottom: '40px', 
        color: '#2d6a4f', 
        fontSize: '32px',
        fontWeight: '700'
      }}>
        Login to Your Account
      </h2>

      {serverError && (
        <div style={{ 
          color: '#dc2626', 
          textAlign: 'center', 
          marginBottom: '25px', 
          padding: '16px 20px',
          backgroundColor: '#fef2f2',
          borderRadius: '12px',
          border: '1px solid #fecaca',
          fontSize: '15px',
          fontWeight: '500'
        }}>
          {serverError}
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate style={{ width: '100%' }}>
        <div style={{ marginBottom: '25px' }}>
          <label style={{ 
            display: 'block', 
            marginBottom: '8px', 
            fontWeight: '600', 
            color: '#374151',
            fontSize: '16px'
          }}>
            Email Address
          </label>
          <input 
            type="email" 
            name="email" 
            value={formData.email} 
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder="Enter your email address"
            autoComplete="email"
            style={{ 
              width: '100%', 
              padding: '16px 20px', 
              borderRadius: '12px', 
              border: errors.email ? '2px solid #dc2626' : '2px solid #e5e7eb', 
              fontSize: '16px',
              transition: 'all 0.3s ease',
              outline: 'none',
              boxSizing: 'border-box'
            }} 
          />
          {errors.email && (
            <p style={{ 
              color: '#dc2626', 
              fontSize: '14px', 
              marginTop: '8px',
              marginBottom: '0',
              fontWeight: '500'
            }}>
              {errors.email}
            </p>
          )}
        </div>

        <div style={{ marginBottom: '35px' }}>
          <label style={{ 
            display: 'block', 
            marginBottom: '8px', 
            fontWeight: '600', 
            color: '#374151',
            fontSize: '16px'
          }}>
            Password
          </label>
          <input 
            type="password" 
            name="password" 
            value={formData.password} 
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder="Enter your password"
            autoComplete="current-password"
            style={{ 
              width: '100%', 
              padding: '16px 20px', 
              borderRadius: '12px', 
              border: errors.password ? '2px solid #dc2626' : '2px solid #e5e7eb', 
              fontSize: '16px',
              transition: 'all 0.3s ease',
              outline: 'none',
              boxSizing: 'border-box'
            }} 
          />
          {errors.password && (
            <p style={{ 
              color: '#dc2626', 
              fontSize: '14px', 
              marginTop: '8px',
              marginBottom: '0',
              fontWeight: '500'
            }}>
              {errors.password}
            </p>
          )}
        </div>

        <button 
          type="submit" 
          disabled={loading}
          style={{ 
            width: '100%', 
            padding: '18px', 
            backgroundColor: loading ? '#94a3b8' : '#2d6a4f', 
            color: 'white', 
            border: 'none', 
            borderRadius: '12px', 
            fontSize: '18px', 
            fontWeight: '600',
            cursor: loading ? 'not-allowed' : 'pointer',
            transition: 'all 0.3s ease',
            boxShadow: loading ? 'none' : '0 4px 12px rgba(45, 106, 79, 0.3)'
          }}
          onMouseOver={(e) => {
            if (!loading) {
              e.currentTarget.style.backgroundColor = '#40916c';
            }
          }}
          onMouseOut={(e) => {
            if (!loading) {
              e.currentTarget.style.backgroundColor = '#2d6a4f';
            }
          }}
        >
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>

      <p style={{ 
        textAlign: 'center', 
        marginTop: '30px', 
        fontSize: '16px',
        color: '#6b7280'
      }}>
        Don't have an account? <Link to="/register" style={{ 
          color: '#2d6a4f', 
          fontWeight: '600',
          textDecoration: 'none',
          transition: 'color 0.3s ease'
        }}>
          Register here
        </Link>
      </p>
    </div>
  );
};

export default Login;