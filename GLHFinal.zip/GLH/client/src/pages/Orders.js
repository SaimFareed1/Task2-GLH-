import { useState, useEffect } from 'react';
import axios from 'axios';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [cancellingOrderId, setCancellingOrderId] = useState(null);

  // Mock user ID - in real app this would come from authentication
  const userId = 1;

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = () => {
    axios.get(`http://localhost:5001/api/orders/${userId}`)
      .then(res => {
        setOrders(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching orders:', err);
        setLoading(false);
      });
  };

  const getStatusColor = (status) => {
    const colors = {
      'pending': '#f59e0b',
      'preparing': '#3b82f6', 
      'ready': '#10b981',
      'completed': '#6b7280',
      'delivered': '#10b981'
    };
    return colors[status] || '#6b7280';
  };

  const getStatusText = (status) => {
    const texts = {
      'pending': 'Order Placed',
      'preparing': 'Preparing',
      'ready': 'Ready for Collection',
      'completed': 'Completed',
      'delivered': 'Delivered'
    };
    return texts[status] || status;
  };

  const getStatusIcon = (status) => {
    const icons = {
      'pending': '📝',
      'preparing': '👨‍🍳',
      'ready': '✅',
      'completed': '🎉',
      'delivered': '🚚'
    };
    return icons[status] || '📝';
  };

  const getOrderProgress = (status) => {
    const progressSteps = [
      { key: 'pending', label: 'Order Placed', completed: true },
      { key: 'preparing', label: 'Preparing', completed: ['preparing', 'ready', 'completed', 'delivered'].includes(status) },
      { key: 'ready', label: 'Ready', completed: ['ready', 'completed', 'delivered'].includes(status) },
      { key: 'completed', label: 'Delivered', completed: ['delivered'].includes(status) }
    ];
    return progressSteps;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const parseOrderItems = (itemsString) => {
    if (!itemsString) return [];
    return itemsString.split(',').map(item => {
      const [productId, quantity, price] = item.split(':');
      return {
        productId: parseInt(productId),
        quantity: parseInt(quantity),
        price: parseFloat(price)
      };
    });
  };

  const canCancelOrder = (status) => {
    return ['pending', 'preparing'].includes(status);
  };

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to cancel this order?')) return;
    
    setCancellingOrderId(orderId);
    try {
      await axios.put(`http://localhost:5001/api/orders/${orderId}/status`, { status: 'cancelled' });
      fetchOrders(); // Refresh orders
    } catch (error) {
      console.error('Error cancelling order:', error);
      alert('Failed to cancel order. Please try again.');
    } finally {
      setCancellingOrderId(null);
    }
  };

  const getEstimatedTime = (status, orderDate) => {
    if (status === 'delivered' || status === 'completed') return 'Delivered';
    if (status === 'ready') return 'Ready for collection';
    if (status === 'preparing') return '15-30 minutes';
    if (status === 'pending') return '30-45 minutes';
    return 'Calculating...';
  };

  if (loading) {
    return (
      <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <p style={{ color: '#666', fontSize: '18px' }}>Loading order history...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 30px' }}>
      <div style={{ marginBottom: '50px' }}>
        <h1 style={{ fontSize: '48px', color: '#2d6a4f', marginBottom: '15px', fontWeight: '700', textAlign: 'center' }}>
          Order Tracking
        </h1>
        <p style={{ textAlign: 'center', color: '#52b788', fontSize: '20px', maxWidth: '700px', margin: '0 auto' }}>
          Track your orders in real-time and stay updated on your fresh local produce deliveries
        </p>
      </div>

      {orders.length === 0 ? (
        <div style={{ 
          background: 'white', 
          padding: '80px 40px', 
          borderRadius: '16px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
        }}>
          <div style={{ fontSize: '64px', marginBottom: '20px' }}>📦</div>
          <h2 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '28px' }}>No orders yet</h2>
          <p style={{ color: '#666', marginBottom: '30px', fontSize: '18px', maxWidth: '400px', margin: '0 auto 30px' }}>
            Start shopping to see your order history and tracking information here
          </p>
          <button 
            onClick={() => window.location.href = '/products'}
            style={{ 
              background: '#2d6a4f', 
              color: 'white', 
              border: 'none', 
              padding: '15px 30px', 
              borderRadius: '8px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Browse Products
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gap: '30px' }}>
          {orders.map(order => {
            const progressSteps = getOrderProgress(order.status);
            const orderItems = parseOrderItems(order.items);
            const isExpanded = selectedOrder === order.id;
            
            return (
              <div 
                key={order.id}
                style={{ 
                  background: 'white', 
                  borderRadius: '16px', 
                  overflow: 'hidden',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                  border: '1px solid #e8f5e9',
                  transition: 'transform 0.3s ease'
                }}
              >
                {/* Order Header */}
                <div style={{ 
                  padding: '30px', 
                  borderBottom: isExpanded ? '1px solid #e8f5e9' : 'none',
                  cursor: 'pointer'
                }}
                onClick={() => setSelectedOrder(isExpanded ? null : order.id)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '10px' }}>
                      <h3 style={{ color: '#2d6a4f', fontSize: '24px', margin: 0, fontWeight: '700' }}>
                        Order #{order.id}
                      </h3>
                      <span style={{ 
                        background: getStatusColor(order.status), 
                        color: 'white', 
                        padding: '6px 12px', 
                        borderRadius: '20px',
                        fontSize: '12px',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '5px'
                      }}>
                        {getStatusIcon(order.status)} {getStatusText(order.status)}
                      </span>
                    </div>
                    <p style={{ color: '#666', margin: '0', fontSize: '16px' }}>
                      {formatDate(order.created_at)}
                    </p>
                    <p style={{ color: '#666', margin: '5px 0 0', fontSize: '16px' }}>
                      {order.order_type === 'delivery' ? '🚚 Delivery' : '🏪 Collection'}
                      {order.order_type === 'delivery' && order.delivery_address && ` to ${order.delivery_address}`}
                      {order.order_type === 'collection' && order.collection_time && ` at ${order.collection_time}`}
                    </p>
                  </div>
                  
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '28px', fontWeight: '700', color: '#2d6a4f', marginBottom: '8px' }}>
                      £{order.total.toFixed(2)}
                    </div>
                    <div style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>
                      {orderItems.length} items
                    </div>
                    <div style={{ fontSize: '14px', color: '#52b788', fontWeight: '500' }}>
                      Est. {getEstimatedTime(order.status, order.created_at)}
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div style={{ marginBottom: '15px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                    {progressSteps.map((step, index) => (
                      <div key={step.key} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
                        <div style={{ 
                          width: '30px', 
                          height: '30px', 
                          borderRadius: '50%', 
                          background: step.completed ? getStatusColor(order.status) : '#e5e7eb',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '14px',
                          marginBottom: '8px',
                          position: 'relative'
                        }}>
                          {step.completed ? '✓' : index + 1}
                          {index < progressSteps.length - 1 && (
                            <div style={{
                              position: 'absolute',
                              top: '15px',
                              left: '50%',
                              width: '100%',
                              height: '2px',
                              background: progressSteps[index + 1].completed ? getStatusColor(order.status) : '#e5e7eb',
                              zIndex: -1
                            }}></div>
                          )}
                        </div>
                        <div style={{ fontSize: '12px', color: step.completed ? '#2d6a4f' : '#9ca3af', textAlign: 'center' }}>
                          {step.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedOrder(isExpanded ? null : order.id);
                    }}
                    style={{
                      background: 'transparent',
                      color: '#2d6a4f',
                      border: '1px solid #2d6a4f',
                      padding: '8px 16px',
                      borderRadius: '6px',
                      fontSize: '14px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    {isExpanded ? 'Hide Details' : 'View Details'}
                  </button>
                  
                  {canCancelOrder(order.status) && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCancelOrder(order.id);
                      }}
                      disabled={cancellingOrderId === order.id}
                      style={{
                        background: cancellingOrderId === order.id ? '#9ca3af' : '#dc2626',
                        color: 'white',
                        border: 'none',
                        padding: '8px 16px',
                        borderRadius: '6px',
                        fontSize: '14px',
                        fontWeight: '600',
                        cursor: cancellingOrderId === order.id ? 'not-allowed' : 'pointer'
                      }}
                    >
                      {cancellingOrderId === order.id ? 'Cancelling...' : 'Cancel Order'}
                    </button>
                  )}
                </div>
              </div>

              {/* Expanded Details */}
              {isExpanded && (
                <div style={{ padding: '30px', background: '#f8f9fa' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
                    {/* Order Items */}
                    <div>
                      <h4 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '18px', fontWeight: '600' }}>
                        Order Items
                      </h4>
                      <div style={{ display: 'grid', gap: '12px' }}>
                        {orderItems.map((item, index) => (
                          <div key={index} style={{ 
                            display: 'flex', 
                            justifyContent: 'space-between', 
                            alignItems: 'center',
                            padding: '12px',
                            background: 'white',
                            borderRadius: '8px',
                            border: '1px solid #e8f5e9'
                          }}>
                            <div>
                              <div style={{ fontWeight: '500', color: '#333', marginBottom: '2px' }}>
                                Item #{item.productId}
                              </div>
                              <div style={{ fontSize: '14px', color: '#666' }}>
                                Quantity: {item.quantity}
                              </div>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                              <div style={{ fontWeight: '600', color: '#2d6a4f' }}>
                                £{item.price.toFixed(2)}
                              </div>
                              <div style={{ fontSize: '12px', color: '#666' }}>
                                each
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Order Details */}
                    <div>
                      <h4 style={{ color: '#2d6a4f', marginBottom: '15px', fontSize: '18px', fontWeight: '600' }}>
                        Order Details
                      </h4>
                      <div style={{ display: 'grid', gap: '12px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: 'white', borderRadius: '8px', border: '1px solid #e8f5e9' }}>
                          <span style={{ color: '#666' }}>Order Type</span>
                          <span style={{ fontWeight: '600', color: '#2d6a4f' }}>
                            {order.order_type === 'delivery' ? 'Delivery' : 'Collection'}
                          </span>
                        </div>
                        
                        {order.order_type === 'delivery' && order.delivery_address && (
                          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: 'white', borderRadius: '8px', border: '1px solid #e8f5e9' }}>
                            <span style={{ color: '#666' }}>Delivery Address</span>
                            <span style={{ fontWeight: '600', color: '#2d6a4f', textAlign: 'right', maxWidth: '200px' }}>
                              {order.delivery_address}
                            </span>
                          </div>
                        )}
                        
                        {order.order_type === 'collection' && order.collection_time && (
                          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: 'white', borderRadius: '8px', border: '1px solid #e8f5e9' }}>
                            <span style={{ color: '#666' }}>Collection Time</span>
                            <span style={{ fontWeight: '600', color: '#2d6a4f' }}>
                              {order.collection_time}
                            </span>
                          </div>
                        )}
                        
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: 'white', borderRadius: '8px', border: '1px solid #e8f5e9' }}>
                          <span style={{ color: '#666' }}>Subtotal</span>
                          <span style={{ fontWeight: '600', color: '#2d6a4f' }}>
                            £{order.total.toFixed(2)}
                          </span>
                        </div>
                        
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: 'white', borderRadius: '8px', border: '1px solid #e8f5e9' }}>
                          <span style={{ color: '#666' }}>Delivery Fee</span>
                          <span style={{ fontWeight: '600', color: '#2d6a4f' }}>
                            {order.order_type === 'delivery' ? '£3.50' : 'Free'}
                          </span>
                        </div>
                        
                        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px', background: '#f0fdf4', borderRadius: '8px', border: '1px solid #52b788' }}>
                          <span style={{ color: '#2d6a4f', fontWeight: '600' }}>Total</span>
                          <span style={{ fontWeight: '700', color: '#2d6a4f', fontSize: '18px' }}>
                            £{order.total.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Help Section */}
                  <div style={{ 
                    marginTop: '20px', 
                    padding: '15px', 
                    background: '#f0fdf4', 
                    borderRadius: '8px',
                    border: '1px solid #52b788'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontSize: '20px' }}>💬</span>
                      <div>
                        <div style={{ fontWeight: '600', color: '#2d6a4f', marginBottom: '2px' }}>
                          Need help with your order?
                        </div>
                        <div style={{ fontSize: '14px', color: '#666' }}>
                          Contact our support team at support@greenfield.local or call 01234 567890
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Stats */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
        gap: '20px', 
        marginTop: '60px' 
      }}>
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>📦</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {orders.length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Total Orders</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🚚</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {orders.filter(o => o.order_type === 'delivery').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Deliveries</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>🏪</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            {orders.filter(o => o.order_type === 'collection').length}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Collections</div>
        </div>
        
        <div style={{ 
          background: 'white', 
          padding: '25px', 
          borderRadius: '12px', 
          textAlign: 'center',
          border: '1px solid #e8f5e9'
        }}>
          <div style={{ fontSize: '32px', marginBottom: '10px' }}>💰</div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: '#2d6a4f', marginBottom: '5px' }}>
            £{orders.reduce((sum, order) => sum + order.total, 0).toFixed(0)}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Total Spent</div>
        </div>
      </div>
    </div>
  );
};

export default Orders;