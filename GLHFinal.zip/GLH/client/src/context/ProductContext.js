import React, { createContext, useState, useEffect } from 'react';

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('allProducts');
    if (saved) return JSON.parse(saved);

    // Keep ALL your original 5 products here
    return [
      {
        id: 1,
        name: "Organic Mixed Salad Leaves",
        description: "Fresh seasonal salad mix including lettuce, rocket, and mizuna",
        price: 2.50,
        unit: "200g",
        stock: 45,
        category: "Vegetables",
        image: "https://picsum.photos/id/1015/600/400",
        producer: "Thompson's Organic Farm"
      },
      {
        id: 2,
        name: "Heritage Tomatoes",
        description: "Heirloom variety tomatoes in various colors",
        price: 4.00,
        unit: "500g",
        stock: 30,
        category: "Vegetables",
        image: "https://picsum.photos/id/292/600/400",
        producer: "Thompson's Organic Farm"
      },
      {
        id: 3,
        name: "Sourdough Loaf",
        description: "Traditional sourdough made with heritage wheat",
        price: 3.50,
        unit: "800g",
        stock: 20,
        category: "Bakery",
        image: "https://picsum.photos/id/201/600/400",
        producer: "Davies Artisan Bakery"
      },
      {
        id: 4,
        name: "Whole Grain Seeded Loaf",
        description: "Hearty bread with pumpkin, sunflower, and flax seeds",
        price: 4.00,
        unit: "800g",
        stock: 15,
        category: "Bakery",
        image: "https://picsum.photos/id/401/600/400",
        producer: "Davies Artisan Bakery"
      },
      {
        id: 5,
        name: "Free Range Eggs",
        description: "Large brown eggs, 12 per pack",
        price: 3.20,
        unit: "12 eggs",
        stock: 34,
        category: "Dairy",
        image: "https://picsum.photos/id/701/600/400",
        producer: "Greenfield Poultry"
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('allProducts', JSON.stringify(products));
  }, [products]);

  const addProduct = (newProduct) => {
    const product = {
      id: Date.now(),
      ...newProduct,
      stock: parseInt(newProduct.stock),
      price: parseFloat(newProduct.price),
    };
    setProducts([...products, product]);
  };

  const updateProduct = (id, updatedFields) => {
    setProducts(products.map(p => 
      p.id === id ? { ...p, ...updatedFields } : p
    ));
  };

  return (
    <ProductContext.Provider value={{ products, addProduct, updateProduct }}>
      {children}
    </ProductContext.Provider>
  );
};