import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { ProductProvider } from './context/ProductContext';   // ← Add this line
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Register from './pages/Register';
import Login from './pages/Login';
import Products from './pages/Products';
import ProductDetails from './pages/ProductDetails';
import Producers from './pages/Producers';
import About from './pages/About';
import Basket from './pages/Basket';
import Account from './pages/Account';
import Dashboard from './pages/Dashboard';
import Checkout from './pages/Checkout';
import Loyalty from './pages/Loyalty';
import Orders from './pages/Orders';

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <CartProvider>
          <ProductProvider>   {/* ← Wrap everything with ProductProvider */}
            <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
              <Router>
                <Navbar />
                <main style={{ flex: 1 }}>
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/products" element={<Products />} />
                    <Route path="/product/:id" element={<ProductDetails />} />
                    <Route path="/producers" element={<Producers />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/basket" element={<Basket />} />
                    <Route path="/checkout" element={<Checkout />} />
                    <Route path="/account" element={<Account />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/loyalty" element={<Loyalty />} />
                    <Route path="/orders" element={<Orders />} />
                  </Routes>
                </main>
                <Footer />
              </Router>
            </div>
          </ProductProvider>
        </CartProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;