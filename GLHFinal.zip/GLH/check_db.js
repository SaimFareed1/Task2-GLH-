const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('glh.db');

console.log('=== CHECKING PRODUCERS TABLE ===');
db.all('SELECT * FROM producers', (err, rows) => {
  if (err) {
    console.error('Error:', err);
  } else {
    console.log('Producers found:', rows.length);
    rows.forEach(producer => {
      console.log(`Producer ID: ${producer.id}, User ID: ${producer.user_id}, Farm Name: ${producer.farm_name}`);
    });
  }
});

console.log('\n=== CHECKING USERS TABLE ===');
db.all('SELECT id, email, full_name, role, business_name FROM users WHERE role = "producer"', (err, rows) => {
  if (err) {
    console.error('Error:', err);
  } else {
    console.log('Producer users found:', rows.length);
    rows.forEach(user => {
      console.log(`User ID: ${user.id}, Email: ${user.email}, Business: ${user.business_name}`);
    });
  }
});

db.close();
