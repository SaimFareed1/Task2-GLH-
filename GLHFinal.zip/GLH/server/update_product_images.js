const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Database path
const dbPath = path.join(__dirname, 'glh.db');
const db = new sqlite3.Database(dbPath);

console.log('=== UPDATING PRODUCT IMAGES ===');

// Product image mappings
const productImages = {
  'Organic Mixed Salad Leaves': 'https://images.pexels.com/photos/30472978/pexels-photo-30472978.jpeg',
  'Heritage Tomatoes': 'https://images.pexels.com/photos/33621806/pexels-photo-33621806.jpeg',
  'Sourdough Loaf': 'https://images.pexels.com/photos/35597416/pexels-photo-35597416.jpeg',
  'Free Range Eggs (6)': 'https://images.pexels.com/photos/7177580/pexels-photo-7177580.png',
  'Raw Cow Milk Cheese': 'https://images.pexels.com/photos/34406232/pexels-photo-34406232.jpeg',
  'Artisan Butter': 'https://images.pexels.com/photos/12162627/pexels-photo-12162627.jpeg',
  'Honey Jar': 'https://images.pexels.com/photos/7990478/pexels-photo-7990478.jpeg',
  'Organic Carrots': 'https://images.pexels.com/photos/35810240/pexels-photo-35810240.jpeg',
  'Apple Cider Vinegar': 'https://images.pexels.com/photos/5471920/pexels-photo-5471920.jpeg',
  'Duck Eggs (6)': 'https://images.pexels.com/photos/9664253/pexels-photo-9664253.jpeg',
  'Rye Sourdough': 'https://images.pexels.com/photos/11214699/pexels-photo-11214699.jpeg'
};

// Update each product's image URL
Object.entries(productImages).forEach(([productName, imageUrl]) => {
  db.run('UPDATE products SET image_url = ? WHERE name = ?', [imageUrl, productName], function(err) {
    if (err) {
      console.error(`Error updating ${productName}:`, err);
    } else {
      console.log(`✅ Updated: ${productName}`);
    }
  });
});

// Check current products after update
setTimeout(() => {
  console.log('\n=== UPDATED PRODUCT LIST ===');
  db.all('SELECT id, name, image_url FROM products ORDER BY id', (err, products) => {
    if (err) {
      console.error('Error fetching products:', err);
    } else {
      products.forEach(product => {
        console.log(`ID: ${product.id}, Name: ${product.name}`);
        console.log(`Image: ${product.image_url}`);
        console.log('---');
      });
    }
    
    db.close();
    console.log('\n✅ Product image update completed!');
  });
}, 1000);
