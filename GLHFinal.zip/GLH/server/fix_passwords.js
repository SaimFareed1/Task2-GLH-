const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

const dbPath = path.join(__dirname, 'glh.db');
const db = new sqlite3.Database(dbPath);

async function fixPasswords() {
  console.log('Fixing user passwords...');
  
  // Generate proper hash for "password123"
  const hashedPassword = await bcrypt.hash('password123', 10);
  console.log('Generated hash for "password123":', hashedPassword);
  
  // Update existing users with proper password hash
  db.run('UPDATE users SET password = ? WHERE password = ?', [hashedPassword, '$2a$10$placeholder'], (err) => {
    if (err) {
      console.error('Error updating passwords:', err);
    } else {
      console.log('Passwords updated successfully!');
      
      // Test the login
      db.get('SELECT email, password FROM users LIMIT 3', (err, users) => {
        if (err) {
          console.error('Error querying users:', err);
        } else {
          console.log('Sample users:');
          users.forEach(user => {
            console.log(`  Email: ${user.email}, Password hash starts with: ${user.password.substring(0, 10)}...`);
          });
        }
        db.close();
      });
    }
  });
}

fixPasswords();
