const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Check database from server directory
const dbPath = path.join(__dirname, 'glh.db');
console.log('Database path:', dbPath);

const db = new sqlite3.Database(dbPath);

console.log('=== DATABASE CONTENTS ===');

// Check users
db.all('SELECT id, email, full_name, role FROM users', (err, users) => {
  if (err) {
    console.error('Error querying users:', err);
  } else {
    console.log('Users found:', users.length);
    users.forEach(user => {
      console.log(`  User ID: ${user.id}, Email: ${user.email}, Role: ${user.role}`);
    });
  }
  
  // Check producers
  db.all('SELECT id, user_id, farm_name FROM producers', (err, producers) => {
    if (err) {
      console.error('Error querying producers:', err);
    } else {
      console.log('Producers found:', producers.length);
      producers.forEach(producer => {
        console.log(`  Producer ID: ${producer.id}, User ID: ${producer.user_id}, Farm: ${producer.farm_name}`);
      });
    }
    
    db.close();
  });
});
