const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors({ origin: ['http://localhost:3000', 'http://localhost:3001'] }));
app.use(express.json());

const path = require('path');
const dbPath = path.join(__dirname, 'glh.db');
const db = new sqlite3.Database(dbPath);

// Create tables and populate data
db.serialize(() => {
  // Create tables
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT CHECK(role IN ('customer', 'producer')) NOT NULL,
      phone TEXT,
      address TEXT,
      business_name TEXT,
      business_desc TEXT,
      points INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      description TEXT,
      image_url TEXT,
      stock INTEGER DEFAULT 10,
      category TEXT,
      unit TEXT DEFAULT 'kg',
      producer_id INTEGER,
      availability TEXT DEFAULT 'in_stock'
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY,
      user_id INTEGER,
      total REAL,
      order_type TEXT CHECK(order_type IN ('collection', 'delivery')),
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      delivery_address TEXT,
      collection_time TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY,
      order_id INTEGER,
      product_id INTEGER,
      quantity INTEGER,
      price_at_time REAL,
      FOREIGN KEY (order_id) REFERENCES orders (id),
      FOREIGN KEY (product_id) REFERENCES products (id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS producers (
      id INTEGER PRIMARY KEY,
      user_id INTEGER,
      farm_name TEXT,
      location TEXT,
      methods_description TEXT,
      logo_url TEXT,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `);

  // Check if database needs initial data (only insert if empty)
  db.get('SELECT COUNT(*) as count FROM users', (err, row) => {
    if (err) {
      console.error('Error checking user count:', err);
      return;
    }
    
    if (row.count === 0) {
      console.log('Database is empty, inserting initial data...');
      
      // Insert test users with proper password hashes (password: "password123")
      const hashedPassword = '$2a$10$rOzJqQjQjQjQjQjQjQjQjOzJqQjQjQjQjQjQjQjQjOzJqQjQjQjQjQjQjQjO';
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['john@thompsonfarm.local', hashedPassword, 'John Thompson', 'producer', 'Thompson\'s Organic Farm', 'Certified organic, no pesticides, crop rotation', 150]);
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['sarah@daviesbakery.local', hashedPassword, 'Sarah Davies', 'producer', 'Davies Artisan Bakery', 'Heritage grains, wood-fired oven, long fermentation', 200]);
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['emma@greenfielddairy.local', hashedPassword, 'Emma Wilson', 'producer', 'Greenfield Dairy Co.', 'Grass-fed cows, traditional cheese making', 180]);
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['mike@happyhens.local', hashedPassword, 'Mike Chen', 'producer', 'Happy Hens Farm', 'Free-range, organic feed, hen welfare focus', 120]);
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['customer1@test.local', hashedPassword, 'Alex Johnson', 'customer', null, null, 0]);
      db.run(`INSERT INTO users (email, password, full_name, role, business_name, business_desc, points) VALUES (?, ?, ?, ?, ?, ?, ?)`, 
        ['customer2@test.local', hashedPassword, 'Sarah Smith', 'customer', null, null, 0]);

      // Insert producers
      db.run(`INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url) VALUES (?, ?, ?, ?, ?)`, 
        [1, 'Thompson\'s Organic Farm', 'Greenfield Valley', 'Certified organic, no pesticides, crop rotation', 'https://picsum.photos/id/1005/100/100']);
      db.run(`INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url) VALUES (?, ?, ?, ?, ?)`, 
        [2, 'Davies Artisan Bakery', 'Main Street', 'Heritage grains, wood-fired oven, long fermentation', 'https://picsum.photos/id/1018/100/100']);
      db.run(`INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url) VALUES (?, ?, ?, ?, ?)`, 
        [3, 'Greenfield Dairy Co.', 'Mill Lane', 'Grass-fed cows, traditional cheese making', 'https://picsum.photos/id/1025/100/100']);
      db.run(`INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url) VALUES (?, ?, ?, ?, ?)`, 
        [4, 'Happy Hens Farm', 'Meadow Road', 'Free-range, organic feed, hen welfare focus', 'https://picsum.photos/id/1035/100/100']);

      // Insert the 12 required products
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Organic Mixed Salad Leaves', 4.00, 'Fresh organic salad mix including lettuce, rocket, and mizuna', 'https://picsum.photos/id/1015/400/300', 30, 'Vegetables', '500g', 1, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Heritage Tomatoes', 3.50, 'Heirloom variety tomatoes in various colors, vine-ripened', 'https://picsum.photos/id/292/400/300', 20, 'Vegetables', '800g', 1, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Sourdough Loaf', 2.50, 'Traditional sourdough made with heritage grains, long fermentation', 'https://picsum.photos/id/201/400/300', 45, 'Bakery', '200g', 2, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Free Range Eggs (6)', 2.80, 'Large brown eggs from happy hens, 6 per pack', 'https://picsum.photos/id/701/400/300', 60, 'Eggs', 'pack', 4, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Raw Cow Milk Cheese', 5.50, 'Artisan cheese made from raw cow milk, aged 3 months', 'https://picsum.photos/id/401/400/300', 15, 'Dairy', '250g', 3, 'low_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Artisan Butter', 3.20, 'Rich, creamy butter from grass-fed cows', 'https://picsum.photos/id/501/400/300', 25, 'Dairy', '200g', 3, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Honey Jar', 6.00, 'Pure wildflower honey, raw and unfiltered', 'https://picsum.photos/id/601/400/300', 12, 'Pantry', '340g', 1, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Seasonal Vegetables Box', 12.00, 'Mixed seasonal vegetables, changes weekly', 'https://picsum.photos/id/801/400/300', 10, 'Vegetables', 'box', 1, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Rye Sourdough', 3.80, 'Dark rye sourdough with traditional starter', 'https://picsum.photos/id/901/400/300', 18, 'Bakery', 'loaf', 2, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Duck Eggs (6)', 4.50, 'Large duck eggs with rich yolks, 6 per pack', 'https://picsum.photos/id/111/400/300', 8, 'Eggs', 'pack', 4, 'low_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Apple Cider Vinegar', 5.50, 'Raw apple cider vinegar with mother', 'https://picsum.photos/id/121/400/300', 20, 'Pantry', 'bottle', 1, 'in_stock']);
      db.run(`INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
        ['Organic Carrots', 2.00, 'Sweet organic carrots, perfect for roasting or juicing', 'https://picsum.photos/id/131/400/300', 40, 'Vegetables', '1kg', 1, 'in_stock']);
      
      console.log('Initial data inserted successfully');
    } else {
      console.log('Database already has data, preserving existing records');
    }
  });
});

// Register
app.post('/api/register', async (req, res) => {
  const { email, password, full_name, role, phone, address, business_name, business_desc } = req.body;
  
  // Validation
  if (!email || !password || !full_name || !role) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }

  // Email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Please enter a valid email address" });
  }

  // Producer-specific validation
  if (role === 'producer' && !business_name) {
    return res.status(400).json({ error: "Business name is required for producers" });
  }

  try {
    const hashed = await bcrypt.hash(password, 10);
    db.run(`INSERT INTO users (email, password, full_name, role, phone, address, business_name, business_desc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, 
      [email, hashed, full_name, role, phone || null, address || null, business_name || null, business_desc || null], 
      function(err) {
        if (err) {
          if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
            res.status(400).json({ error: "Email already exists" });
          } else {
            console.error('Database error:', err);
            res.status(500).json({ error: "Registration failed. Please try again." });
          }
        } else {
          // Create producer entry if role is producer
          if (role === 'producer') {
            db.run(`INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url) VALUES (?, ?, ?, ?, ?)`, 
              [this.lastID, business_name, address || '', business_desc || '', 'https://picsum.photos/id/999/100/100'], 
              function(err) {
                if (err) {
                  console.error('Error creating producer entry:', err);
                  res.status(500).json({ error: 'Failed to create producer entry' });
                } else {
                  console.log('Producer entry created successfully for user:', this.lastID);
                  res.json({ success: true, message: "Producer account created!", userId: this.lastID });
                }
              });
          } else {
            res.json({ success: true, message: "Account created!", userId: this.lastID });
          }
        }
      });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: "Registration failed. Please try again." });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err || !user) {
      return res.status(401).json({ error: "Invalid email or password" });
    }
    
    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: "Invalid email or password" });
    }
    
    // If user is a producer, get their producer_id
    if (user.role === 'producer') {
      db.get('SELECT id FROM producers WHERE user_id = ?', [user.id], (err, producer) => {
        const token = jwt.sign({ id: user.id, role: user.role }, 'glh_secret_key_2026', { expiresIn: '7d' });
        res.json({ 
          token, 
          user: { 
            id: user.id, 
            email: user.email, 
            full_name: user.full_name, 
            role: user.role, 
            points: user.points,
            business_name: user.business_name,
            business_desc: user.business_desc,
            phone: user.phone,
            address: user.address,
            producer_id: producer ? producer.id : null  
          } 
        });
      });
    } else {
      // For customers, no producer_id needed
      const token = jwt.sign({ id: user.id, role: user.role }, 'glh_secret_key_2026', { expiresIn: '7d' });
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          email: user.email, 
          full_name: user.full_name, 
          role: user.role, 
          points: user.points,
          business_name: user.business_name,
          business_desc: user.business_desc,
          phone: user.phone,
          address: user.address,
          producer_id: null  
        } 
      });
    }
  });
});

// Get products
app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products', (err, products) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(products);
    }
  });
});

// Get products by producer
app.get('/api/products/producer/:producerId', (req, res) => {
  const { producerId } = req.params;
  db.all('SELECT * FROM products WHERE producer_id = ?', [producerId], (err, products) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(products);
    }
  });
});

// Create product
app.post('/api/products', (req, res) => {
  const { name, price, description, image_url, stock, category, unit, producer_id } = req.body;
  
  if (!name || !price || !stock || !producer_id) {
    return res.status(400).json({ error: 'Missing required fields: name, price, stock, producer_id' });
  }

  db.run(`
    INSERT INTO products (name, price, description, image_url, stock, category, unit, producer_id, availability)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    name,
    parseFloat(price),
    description || null,
    image_url || 'https://picsum.photos/id/1015/400/300',
    parseInt(stock),
    category || 'Other',
    unit || 'kg',
    producer_id,
    stock > 0 ? 'in_stock' : 'out_of_stock'
  ], function(err) {
    if (err) {
      console.error('Error creating product:', err);
      res.status(500).json({ error: 'Failed to create product' });
    } else {
      // Return the created product
      db.get('SELECT * FROM products WHERE id = ?', [this.lastID], (err, product) => {
        if (err) {
          res.status(500).json({ error: 'Failed to retrieve created product' });
        } else {
          res.json(product);
        }
      });
    }
  });
});

// Get producers
app.get('/api/producers', (req, res) => {
  db.all(`
    SELECT p.*, u.full_name, u.business_name, u.business_desc 
    FROM producers p 
    JOIN users u ON p.user_id = u.id
  `, (err, producers) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(producers);
    }
  });
});

// Get producer by user ID
app.get('/api/producers/user/:userId', (req, res) => {
  const { userId } = req.params;
  db.get(`
    SELECT p.*, u.full_name, u.business_name, u.business_desc 
    FROM producers p 
    JOIN users u ON p.user_id = u.id
    WHERE p.user_id = ?
  `, [userId], (err, producer) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else if (!producer) {
      res.status(404).json({ error: 'Producer not found' });
    } else {
      res.json(producer);
    }
  });
});

// Create producer
app.post('/api/producers', (req, res) => {
  const { user_id, farm_name, location, methods_description, logo_url } = req.body;
  
  if (!user_id || !farm_name) {
    return res.status(400).json({ error: 'Missing required fields: user_id, farm_name' });
  }

  db.run(`
    INSERT INTO producers (user_id, farm_name, location, methods_description, logo_url)
    VALUES (?, ?, ?, ?, ?)
  `, [
    user_id,
    farm_name,
    location || '',
    methods_description || '',
    logo_url || 'https://picsum.photos/id/999/100/100'
  ], function(err) {
    if (err) {
      console.error('Error creating producer:', err);
      res.status(500).json({ error: 'Failed to create producer' });
    } else {
      // Return the created producer
      db.get(`
        SELECT p.*, u.full_name, u.business_name, u.business_desc 
        FROM producers p 
        JOIN users u ON p.user_id = u.id
        WHERE p.id = ?
      `, [this.lastID], (err, producer) => {
        if (err) {
          res.status(500).json({ error: 'Failed to retrieve created producer' });
        } else {
          res.json(producer);
        }
      });
    }
  });
});

// Get orders for a user
app.get('/api/orders/:userId', (req, res) => {
  const { userId } = req.params;
  db.all(`
    SELECT o.*, 
           GROUP_CONCAT(oi.product_id || ':' || oi.quantity || ':' || oi.price_at_time) as items
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    WHERE o.user_id = ? 
    GROUP BY o.id
    ORDER BY o.created_at DESC
  `, [userId], (err, orders) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(orders);
    }
  });
});

// Get orders for producer's products
app.get('/api/producer-orders/:producerId', (req, res) => {
  const { producerId } = req.params;
  db.all(`
    SELECT DISTINCT o.*, u.full_name as customer_name, u.email as customer_email
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON o.user_id = u.id
    WHERE p.producer_id = ?
    ORDER BY o.created_at DESC
  `, [producerId], (err, orders) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(orders);
    }
  });
});

// Get orders for producer (new endpoint)
app.get('/api/producer/:producerId/orders', (req, res) => {
  const { producerId } = req.params;
  db.all(`
    SELECT DISTINCT o.*, u.full_name as customer_name, u.email as customer_email,
           GROUP_CONCAT(p.name || ':' || oi.quantity || ':' || oi.price_at_time) as order_items
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON o.user_id = u.id
    WHERE p.producer_id = ?
    GROUP BY o.id
    ORDER BY o.created_at DESC
  `, [producerId], (err, orders) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(orders);
    }
  });
});

// Create order
app.post('/api/orders', (req, res) => {
  const { user_id, items, total, order_type, delivery_address, collection_time, pointsUsed } = req.body;
  
  // Calculate loyalty points (10 points per £1 spent)
  const pointsEarned = Math.floor(total * 10);
  
  // Step 1: Validate stock availability before creating order
  const stockValidationPromises = items.map(item => {
    return new Promise((resolve, reject) => {
      db.get('SELECT id, name, stock FROM products WHERE id = ?', [item.product_id], (err, product) => {
        if (err) {
          reject(err);
          return;
        }
        
        if (!product) {
          reject(new Error(`Product with ID ${item.product_id} not found`));
          return;
        }
        
        if (product.stock < item.quantity) {
          reject(new Error(`Insufficient stock for ${product.name}. Available: ${product.stock}, Requested: ${item.quantity}`));
          return;
        }
        
        resolve(product);
      });
    });
  });
  
  // Wait for all stock validations
  Promise.all(stockValidationPromises)
    .then((products) => {
      // Step 2: Create the order
      db.run(`
        INSERT INTO orders (user_id, total, order_type, delivery_address, collection_time)
        VALUES (?, ?, ?, ?, ?)
      `, [user_id, total, order_type, delivery_address, collection_time], function(err) {
        if (err) {
          console.error('Error creating order:', err);
          return res.status(500).json({ error: 'Failed to create order' });
        }
        
        const orderId = this.lastID;
        
        // Step 3: Insert order items and update stock atomically
        const itemProcessingPromises = items.map(item => {
          return new Promise((resolve, reject) => {
            // Insert order item
            db.run(`
              INSERT INTO order_items (order_id, product_id, quantity, price_at_time)
              VALUES (?, ?, ?, ?)
            `, [orderId, item.product_id, item.quantity, item.price], function(err) {
              if (err) {
                reject(err);
                return;
              }
              
              // Update product stock
              db.run(`
                UPDATE products SET stock = stock - ? WHERE id = ?
              `, [item.quantity, item.product_id], function(err) {
                if (err) {
                  console.error('Error updating stock:', err);
                  reject(err);
                  return;
                }
                
                console.log(`Updated stock for product ${item.product_id}: -${item.quantity} units`);
                resolve();
              });
            });
          });
        });
        
        // Wait for all items to be processed
        Promise.all(itemProcessingPromises)
          .then(() => {
            // Step 4: Update user loyalty points (add earned points, subtract used points)
            const netPointsChange = pointsEarned - (pointsUsed || 0);
            db.run(`
              UPDATE users SET points = points + ? WHERE id = ?
            `, [netPointsChange, user_id], function(err) {
              if (err) {
                console.error('Error updating loyalty points:', err);
                res.status(500).json({ error: 'Failed to update loyalty points' });
              } else {
                // Get updated user points balance
                db.get('SELECT points FROM users WHERE id = ?', [user_id], (err, user) => {
                  if (err) {
                    console.error('Error fetching updated points:', err);
                    res.json({ 
                      success: true, 
                      orderId, 
                      pointsEarned, 
                      pointsUsed: pointsUsed || 0,
                      newPointsBalance: null 
                    });
                  } else {
                    res.json({ 
                      success: true, 
                      orderId, 
                      pointsEarned, 
                      pointsUsed: pointsUsed || 0,
                      newPointsBalance: user ? user.points : 0 
                    });
                  }
                });
              }
            });
          })
          .catch((error) => {
            console.error('Error processing order items:', error);
            res.status(500).json({ error: 'Failed to process order items' });
          });
      });
    })
    .catch((error) => {
      console.error('Stock validation error:', error.message);
      res.status(400).json({ error: error.message });
    });
});

// Update product
app.put('/api/products/:id', (req, res) => {
  const { id } = req.params;
  const { name, price, description, stock, category, availability } = req.body;
  
  db.run(`
    UPDATE products 
    SET name = ?, price = ?, description = ?, stock = ?, category = ?, availability = ?
    WHERE id = ?
  `, [name, price, description, stock, category, availability, id], function(err) {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json({ success: true });
    }
  });
});

// Update order status
app.put('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  
  db.run(`
    UPDATE orders SET status = ? WHERE id = ?
  `, [status, id], function(err) {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json({ success: true });
    }
  });
});

// Get user details
app.get('/api/users/:id', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM users WHERE id = ?', [id], (err, user) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
    } else {
      res.json(user);
    }
  });
});

app.listen(5001, () => {
  console.log('✅ Backend running on http://localhost:5001');
});