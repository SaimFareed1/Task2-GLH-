const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('glh.db');

console.log('=== LATEST PRODUCERS ===');
db.all('SELECT p.*, u.email, u.full_name, u.business_name FROM producers p JOIN users u ON p.user_id = u.id ORDER BY p.id DESC LIMIT 5', (err, rows) => {
  if (err) {
    console.error('Error:', err);
  } else {
    console.log('Found', rows.length, 'producers:');
    rows.forEach(p => {
      console.log(`Producer ID: ${p.id}, User ID: ${p.user_id}, Email: ${p.email}, Business: ${p.business_name}, Farm: ${p.farm_name}`);
    });
  }
  db.close();
});
