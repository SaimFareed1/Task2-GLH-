import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import axios from 'axios';

const Producers = () => {
  const [producers, setProducers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/producers')
      .then(res => setProducers(res.data));
  }, []);

  return (
    <div style={{ maxWidth: '1100px', margin: '40px auto', padding: '0 20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px', color: '#166534' }}>Our Producers</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '30px' }}>
        {producers.map(p => (
          <div key={p.id} style={{ border: '1px solid #ddd', borderRadius: '12px', padding: '20px', background: 'white' }}>
            <h3>{p.name}</h3>
            <p>{p.business_name}</p>
            <p style={{ fontSize: '14px', color: '#555' }}>{p.description}</p>
            <p><strong>Location:</strong> {p.location}</p>
          </div>
        ))}
      </div>

      <h2 style={{ marginTop: '50px', textAlign: 'center' }}>Map of Producers</h2>
      <MapContainer center={[52.0, -0.5]} zoom={10} style={{ height: '500px', width: '100%', borderRadius: '12px' }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {producers.map(p => (
          <Marker key={p.id} position={[52.0, -0.5]}>
            <Popup>{p.name}<br/>{p.business_name}</Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default Producers;