import { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

const Basket = () => {
  const { cart, removeFromCart, clearCart } = useContext(CartContext);
  const navigate = useNavigate();

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handlePlaceOrder = () => {
    if (cart.length === 0) return;
    alert(`Order placed successfully! Total: £${total.toFixed(2)}`);
    clearCart();
    navigate('/');
  };

  return (
    <div style={{ maxWidth: '900px', margin: '40px auto', padding: '0 20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px' }}>Your Basket</h1>

      {cart.length === 0 ? (
        <p style={{ textAlign: 'center', fontSize: '20px' }}>Your basket is empty</p>
      ) : (
        <>
          {cart.map(item => (
            <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '15px', borderBottom: '1px solid #ddd', marginBottom: '10px' }}>
              <div>
                <h3>{item.name}</h3>
                <p>£{item.price} × {item.quantity}</p>
              </div>
              <div>
                <button onClick={() => removeFromCart(item.id)} style={{ background: '#dc2626', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px' }}>
                  Remove
                </button>
              </div>
            </div>
          ))}

          <div style={{ textAlign: 'right', marginTop: '30px', fontSize: '24px', fontWeight: 'bold' }}>
            Total: £{total.toFixed(2)}
          </div>

          <button 
            onClick={handlePlaceOrder}
            style={{ width: '100%', padding: '18px', background: '#166534', color: 'white', border: 'none', borderRadius: '12px', fontSize: '20px', marginTop: '30px' }}
          >
            Place Order
          </button>
        </>
      )}
    </div>
  );
};

export default Basket;