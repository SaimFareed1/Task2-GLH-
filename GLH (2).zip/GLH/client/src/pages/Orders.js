const Orders = () => {
    return (
      <div style={{ padding: '40px' }}>
        <h1>Order History</h1>
        <p>No orders yet</p>
      </div>
    );
  };
  
  export default Orders;