import React, { useState, useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { Link } from 'react-router-dom';

const mockProducts = [
  {
    id: 1,
    name: "Organic Mixed Salad Leaves",
    description: "Fresh seasonal salad mix including lettuce, rocket, and mizuna",
    price: 2.50,
    unit: "200g",
    stock: 45,
    producer: "Thompson's Organic Farm",
    image: "https://picsum.photos/id/1015/600/400"
  },
  {
    id: 2,
    name: "Heritage Tomatoes",
    description: "Heirloom variety tomatoes in various colors",
    price: 4.00,
    unit: "500g",
    stock: 30,
    producer: "Thompson's Organic Farm",
    image: "https://picsum.photos/id/201/600/400"
  },
  {
    id: 3,
    name: "Sourdough Loaf",
    description: "Traditional sourdough made with heritage wheat",
    price: 3.50,
    unit: "800g",
    stock: 20,
    producer: "Davies Artisan Bakery",
    image: "https://picsum.photos/id/301/600/400"
  },
  {
    id: 4,
    name: "Whole Grain Seeded Loaf",
    description: "Hearty bread with pumpkin, sunflower, and flax seeds",
    price: 4.00,
    unit: "800g",
    stock: 15,
    producer: "Davies Artisan Bakery",
    image: "https://picsum.photos/id/401/600/400"
  },
  {
    id: 5,
    name: "Stilton & Fig Cheese",
    description: "Award-winning blue cheese with dried figs",
    price: 6.50,
    unit: "250g",
    stock: 8,
    producer: "Davies Artisan Dairy",
    image: "https://picsum.photos/id/501/600/400"
  },
  {
    id: 6,
    name: "Whole Milk",
    description: "Fresh from local dairy",
    price: 1.80,
    unit: "1L",
    stock: 65,
    producer: "Davies Artisan Dairy",
    image: "https://picsum.photos/id/601/600/400"
  },
  {
    id: 7,
    name: "Free Range Eggs",
    description: "Large brown eggs, 12 per pack",
    price: 3.20,
    unit: "12 eggs",
    stock: 34,
    producer: "Thompson's Organic Farm",
    image: "https://picsum.photos/id/701/600/400"
  },
  {
    id: 8,
    name: "Raw Wildflower Honey",
    description: "Harvested from local beehives",
    price: 5.50,
    unit: "340g",
    stock: 22,
    producer: "Local Apiary",
    image: "https://picsum.photos/id/801/600/400"
  }
];

const Products = () => {
  const { addToCart } = useContext(CartContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Vegetables', 'Bakery', 'Dairy', 'Eggs', 'Pantry'];

  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="products-page">
      <div className="products-wrapper">
        <h1 className="products-title">Our Products</h1>
        <p className="products-subtitle">
          Fresh, locally-produced food with transparent pricing and full traceability
        </p>

        {/* Search */}
        <div className="search-container">
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <span className="search-icon">🔎</span>
        </div>

        {/* Category Filters */}
        <div className="category-filters">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`category-btn ${selectedCategory === cat ? 'active' : ''}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="product-grid">
          {filteredProducts.map(product => (
            <div key={product.id} className="product-card">
              <Link to={`/product/${product.id}`}>
                <img src={product.image} alt={product.name} />
              </Link>
              <div className="product-info">
                <h3 className="product-name">{product.name}</h3>
                <p className="product-desc">{product.description}</p>
                
                <div className="product-meta">
                  <div>
                    <span className="product-price">£{product.price.toFixed(2)}</span>
                    <span style={{fontSize: '14px', color: '#6b7280'}}> / {product.unit}</span>
                  </div>
                  <span className="stock-badge">In stock ({product.stock})</span>
                </div>

                <button
                  onClick={(e) => {
                    e.preventDefault();
                    addToCart(product);
                  }}
                  className="add-btn"
                >
                  🛒 Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <p style={{textAlign: 'center', fontSize: '24px', color: '#6b7280', padding: '60px 0'}}>
            No products found 😔
          </p>
        )}
      </div>
    </div>
  );
};

export default Products;