const Home = () => {
    return (
      <div style={{ minHeight: '100vh', backgroundColor: '#f1f8f3', paddingTop: '80px' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 30px', textAlign: 'center' }}>
          <h1 style={{ fontSize: '52px', fontWeight: '700', color: '#166534', marginBottom: '20px' }}>
            Greenfield Local Hub
          </h1>
          <p style={{ fontSize: '24px', color: '#444', marginBottom: '40px' }}>
            Connecting you with fresh, local, sustainable produce from your community
          </p>
          
          <div style={{ display: 'flex', gap: '20px', justifyContent: 'center' }}>
            <a href="/products" style={{ backgroundColor: '#166534', color: 'white', padding: '18px 40px', borderRadius: '12px', fontSize: '20px', textDecoration: 'none' }}>
              Browse Products
            </a>
            <a href="/producers" style={{ border: '2px solid #166534', color: '#166534', padding: '18px 40px', borderRadius: '12px', fontSize: '20px', textDecoration: 'none' }}>
              Meet Our Producers
            </a>
          </div>
        </div>
      </div>
    );
  };
  
  export default Home;