const Account = () => {
    return (
      <div style={{ maxWidth: '800px', margin: '40px auto', padding: '0 30px' }}>
        <h1 style={{ textAlign: 'center', color: '#166534' }}>My Account</h1>
        <p style={{ textAlign: 'center', fontSize: '20px' }}>Order history and loyalty points coming soon...</p>
        {/* We can expand this later with real data from backend */}
      </div>
    );
  };
  
  export default Account;