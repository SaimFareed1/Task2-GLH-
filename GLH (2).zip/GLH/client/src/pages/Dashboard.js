const Dashboard = () => {
    return (
      <div style={{ padding: '40px' }}>
        <h1>Producer Dashboard</h1>
  
        <h2>My Products</h2>
        <button>Add Product</button>
  
        <h2>Orders</h2>
        <p>View orders here</p>
      </div>
    );
  };
  
  export default Dashboard;