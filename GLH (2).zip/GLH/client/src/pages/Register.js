import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [form, setForm] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    full_name: '',
    role: 'customer',
    phone: '',
    address: '',
    business_name: '',
    business_desc: ''
  });

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError(''); // clear error when typing
  };

  const validateForm = () => {
    if (!form.email || !form.password || !form.full_name) {
      setError('All required fields must be filled');
      return false;
    }
    if (!/\S+@\S+\.\S+/.test(form.email)) {
      setError('Please enter a valid email address');
      return false;
    }
    if (form.password.length < 8) {
      setError('Password must be at least 8 characters long');
      return false;
    }
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validateForm()) return;

    try {
      const res = await axios.post('http://localhost:5000/api/register', form);
      if (res.data.success) {
        setSuccess('Account created successfully! Redirecting to login...');
        setTimeout(() => {
          navigate('/login');
        }, 1500);
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed. Try again.');
    }
  };

  return (
    <div style={{ maxWidth: '520px', margin: '60px auto', padding: '40px', background: 'white', borderRadius: '16px', boxShadow: '0 10px 40px rgba(0,0,0,0.1)' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '30px', color: '#166534' }}>Create Your Account</h2>

      {error && <p style={{ color: 'red', textAlign: 'center', marginBottom: '15px' }}>{error}</p>}
      {success && <p style={{ color: 'green', textAlign: 'center', marginBottom: '15px' }}>{success}</p>}

      <form onSubmit={handleSubmit}>
        <select 
          name="role" 
          value={form.role} 
          onChange={handleChange}
          style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }}
        >
          <option value="customer">Customer - I want to buy local products</option>
          <option value="producer">Producer - I want to sell my products</option>
        </select>

        <input 
          name="full_name" 
          placeholder="Full Name *" 
          value={form.full_name}
          onChange={handleChange} 
          required 
          style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
        />

        <input 
          name="email" 
          type="email" 
          placeholder="Email *" 
          value={form.email}
          onChange={handleChange} 
          required 
          style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
        />

        <input 
          name="password" 
          type="password" 
          placeholder="Password (min 8 characters) *" 
          value={form.password}
          onChange={handleChange} 
          required 
          style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
        />

        <input 
          name="confirmPassword" 
          type="password" 
          placeholder="Confirm Password *" 
          value={form.confirmPassword}
          onChange={handleChange} 
          required 
          style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
        />

        {form.role === 'producer' && (
          <>
            <input 
              name="business_name" 
              placeholder="Business / Farm Name" 
              value={form.business_name}
              onChange={handleChange} 
              style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
            />
            <textarea 
              name="business_desc" 
              placeholder="Tell us about your farm or business..." 
              value={form.business_desc}
              onChange={handleChange} 
              rows="4"
              style={{ width: '100%', padding: '14px', marginBottom: '18px', borderRadius: '8px', border: '1px solid #ccc' }} 
            />
          </>
        )}

        <button 
          type="submit" 
          style={{ width: '100%', padding: '16px', background: '#166534', color: 'white', border: 'none', borderRadius: '12px', fontSize: '18px', fontWeight: '600', cursor: 'pointer' }}
        >
          Create Account
        </button>
      </form>

      <p style={{ textAlign: 'center', marginTop: '25px' }}>
        Already have an account? <a href="/login" style={{ color: '#166534', fontWeight: '600' }}>Login here</a>
      </p>
    </div>
  );
};

export default Register;