import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/products/${id}`)
      .then(res => setProduct(res.data))
      .catch(err => console.error(err));
  }, [id]);

  if (!product) return <p>Loading...</p>;

  return (
    <div style={{ padding: '40px' }}>
      <img src={product.image_url} alt={product.name} style={{ width: '300px' }} />
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <h2>£{product.price}</h2>
      <p>{product.stock > 0 ? "Available" : "Out of stock"}</p>
    </div>
  );
};

export default ProductDetails;