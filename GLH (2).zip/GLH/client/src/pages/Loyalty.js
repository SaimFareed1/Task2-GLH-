const Loyalty = () => {
    return (
      <div style={{ padding: '40px' }}>
        <h1>Loyalty Program</h1>
        <p>You have 120 points</p>
        <p>Earn 1 point per £1 spent</p>
        <p>200 points = £5 discount</p>
      </div>
    );
  };
  
  export default Loyalty;