const About = () => {
    return (
      <div style={{ maxWidth: '900px', margin: '40px auto', padding: '0 30px', lineHeight: '1.7' }}>
        <h1 style={{ textAlign: 'center', color: '#166534' }}>About Greenfield Local Hub</h1>
        <p style={{ fontSize: '20px', textAlign: 'center', margin: '30px 0' }}>
          We are a cooperative of local farmers and food producers committed to bringing fresh, sustainable, and traceable food to our community.
        </p>
        <h2>Why Buy Local?</h2>
        <ul style={{ fontSize: '18px' }}>
          <li>🌱 Supports local economy</li>
          <li>🌍 Reduces carbon footprint</li>
          <li>🥕 Fresher, higher quality produce</li>
          <li>🤝 Builds community connections</li>
        </ul>
      </div>
    );
  };
  
  export default About;