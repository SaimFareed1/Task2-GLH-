const Checkout = () => {
    return (
      <div style={{ padding: '40px' }}>
        <h1>Checkout</h1>
  
        <label>Delivery Method</label>
        <select>
          <option>Collection</option>
          <option>Delivery</option>
        </select>
  
        <br /><br />
  
        <label>Address</label>
        <input type="text" placeholder="Enter address" />
  
        <br /><br />
  
        <button>Place Order</button>
      </div>
    );
  };
  
  export default Checkout;