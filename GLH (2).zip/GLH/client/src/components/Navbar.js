import { Link } from 'react-router-dom';
import { useContext, useState, useEffect } from 'react';
import { ThemeContext } from '../context/ThemeContext';
import { FiSun, FiMoon, FiShoppingCart, FiUser } from 'react-icons/fi';

const Navbar = () => {
  const { darkMode, setDarkMode } = useContext(ThemeContext);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/login';
  };

  return (
    <nav style={{
      backgroundColor: '#166534',
      color: 'white',
      padding: '20px 0',
      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <span style={{ fontSize: '32px', fontWeight: 'bold' }}>GLH</span>
          <div>
            <div style={{ fontSize: '20px', fontWeight: '600' }}>Greenfield Local Hub</div>
            <div style={{ fontSize: '13px', color: '#a5f0c2' }}>Fresh • Local • Sustainable</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '32px', fontSize: '17px', fontWeight: '500' }}>
          <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>Home</Link>
          <Link to="/products" style={{ color: 'white', textDecoration: 'none' }}>Products</Link>
          <Link to="/producers" style={{ color: 'white', textDecoration: 'none' }}>Producers</Link>
          <Link to="/about" style={{ color: 'white', textDecoration: 'none' }}>About</Link>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <Link to="/basket" style={{ fontSize: '26px', color: 'white' }}>
            <FiShoppingCart />
          </Link>

          {isLoggedIn ? (
            <>
              <Link to="/account" style={{ fontSize: '26px', color: 'white' }}>
                <FiUser />
              </Link>
              <button onClick={handleLogout} style={{ background: 'white', color: '#166534', padding: '8px 20px', borderRadius: '8px', fontWeight: '600' }}>
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" style={{ background: 'white', color: '#166534', padding: '10px 24px', borderRadius: '8px', fontWeight: '600' }}>
              Login / Register
            </Link>
          )}

          <button onClick={() => setDarkMode(!darkMode)} style={{ fontSize: '26px', color: 'white' }}>
            {darkMode ? <FiSun /> : <FiMoon />}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;