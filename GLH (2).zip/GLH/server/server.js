const express = require('express');
const cors = require('cors');
const sqlite3 = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors({ origin: 'http://localhost:3000' }));
app.use(express.json());

const db = new sqlite3('glh.db');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT CHECK(role IN ('customer', 'producer')) NOT NULL,
    phone TEXT,
    address TEXT,
    business_name TEXT,
    business_desc TEXT,
    points INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT,
    image_url TEXT,
    stock INTEGER DEFAULT 10,
    category TEXT,
    producer_id INTEGER
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    total REAL,
    order_type TEXT CHECK(order_type IN ('collection', 'delivery')),
    status TEXT DEFAULT 'pending',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    items TEXT
  );
`);

// Sample products
db.prepare(`
  INSERT OR IGNORE INTO products (name, price, description, image_url, stock, category, producer_id) VALUES
  ('Organic Carrots', 2.50, 'Fresh 1kg local carrots', 'https://picsum.photos/id/1080/300/200', 45, 'Vegetables', 1),
  ('Heritage Tomatoes', 4.00, 'Sweet heritage tomatoes', 'https://picsum.photos/id/292/300/200', 30, 'Vegetables', 1),
  ('Sourdough Loaf', 3.50, 'Artisan sourdough bread', 'https://picsum.photos/id/201/300/200', 25, 'Bakery', 2),
  ('Free Range Eggs', 2.80, '12 free-range eggs', 'https://picsum.photos/id/870/300/200', 40, 'Dairy', 1)
`).run();

// Register
app.post('/api/register', async (req, res) => {
  const { email, password, full_name, role, phone, address, business_name, business_desc } = req.body;
  if (!email || !password || !full_name || !role) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const hashed = await bcrypt.hash(password, 10);
  try {
    const stmt = db.prepare(`INSERT INTO users (email, password, full_name, role, phone, address, business_name, business_desc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    stmt.run(email, hashed, full_name, role, phone || null, address || null, business_name || null, business_desc || null);
    res.json({ success: true, message: "Account created!" });
  } catch (e) {
    res.status(400).json({ error: "Email already exists" });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, 'glh_secret_key_2026', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, full_name: user.full_name, role: user.role, points: user.points } });
});

// Get products
app.get('/api/products', (req, res) => {
  const products = db.prepare('SELECT * FROM products').all();
  res.json(products);
});

app.listen(5000, () => {
  console.log('✅ Backend running on http://localhost:5000');
});